function elast = elast_hdd_het(b0)
    global rhsvar hetvar numc;
    % HDD302 is the 10th, CDD302 is the 11th, and HDDCDD is the 12th beta
    % HDD302 is the 2nd gamma 
    betas  = b0(1:numc);
    gammas = b0(numc+1:end);
    
    zrhs = rhsvar*betas;
    zhet = exp(hetvar*gammas);

    y_hat = normcdf(zrhs./zhet);

    elast1 = normpdf(zrhs./zhet) .* ...
             ((b0(10) + rhsvar(:,11).*b0(12) - zrhs.*gammas(2)) ./zhet) .* ...
             (rhsvar(:,10) ./ y_hat);
    elast = mean(elast1);
end
