function ret=sse_fn(betas)
  global depvar func_name
  output=feval(func_name,betas) ;
  u= depvar - output;
  ret=u'*u;
end
