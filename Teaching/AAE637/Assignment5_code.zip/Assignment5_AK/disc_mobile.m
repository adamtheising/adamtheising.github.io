function change = disc_mobile(b0)
    global rhsvar;
    nonmob = [1:14]; % Mobile is the 15th (last) var
    z_mobile = rhsvar(:,nonmob) * b0(nonmob) + rhsvar(:,1) * b0(15);
    z_nonmob = rhsvar(:,nonmob) * b0(nonmob) + 0;
    change = mean(normcdf(z_mobile) - normcdf(z_nonmob));
end
