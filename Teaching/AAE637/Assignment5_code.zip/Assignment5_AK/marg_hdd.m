function marg = marg_hdd(b0)
    global rhsvar;
    % HDD302 is the 10th, CDD302 is the 11th, and HDDCDD is the 12th var 
    marg1 = normpdf(rhsvar*b0) .* (b0(10) + rhsvar(:,11)*b0(12));
    marg = mean(marg1);
end
