function [tot_llf] = probit_llf_res(b0)
   global rhsres depvar;
   cdf_prob = normcdf(rhsres*b0);
   llf = depvar.*log(cdf_prob) + (1-depvar).*log(1-cdf_prob);
   tot_llf=sum(llf);    
end

