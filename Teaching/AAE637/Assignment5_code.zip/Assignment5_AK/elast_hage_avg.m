function elast = elast_hage_avg(b0)
    global rhsvar;
    % HouseAge is the 13th var 
    y_hat = normcdf(rhsvar*b0);
    elast1 = normpdf(rhsvar*b0) .* b0(13) .* (rhsvar(:,13) ./ y_hat);
    elast = mean(elast1);
end
