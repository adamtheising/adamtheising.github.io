function diff = elast_hage_diff(b0)
    global rhsvar;
    % HouseAge is the 13th var 
    y_hat = normcdf(rhsvar*b0);
    elast1 = normpdf(rhsvar*b0) .* b0(13) .*  (rhsvar(:,13) ./ y_hat);
    e_avg = mean(elast1);

    means = mean(rhsvar);
%   mean_y_hat = mean(normcdf(rhsvar*b0));
    mean_y_hat = normcdf(means*b0);
    e_mean = normpdf(means*b0) .* b0(13) .*  (means(:,13) ./ mean_y_hat);

    diff = e_avg - e_mean;
end
