function elast = elast_hage_mean(b0)
    global rhsvar;
    % HouseAge is the 13th var 
    means = mean(rhsvar);
%   mean_y_hat = mean(normcdf(rhsvar*b0));
    mean_y_hat = normcdf(means*b0);
    elast = normpdf(means*b0) .* b0(13) .*  (means(:,13) ./ mean_y_hat);
end

