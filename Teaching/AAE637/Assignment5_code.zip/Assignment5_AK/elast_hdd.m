function elast = elast_hdd(b0)
    global rhsvar;
    % HDD302 is the 10th, CDD302 is the 11th, and HDDCDD is the 12th var 
    y_hat = normcdf(rhsvar*b0);
    elast1 = normpdf(rhsvar*b0) .* (b0(10) + rhsvar(:,11).*b0(12)) .* ...
            (rhsvar(:,10) ./ y_hat);
    elast = mean(elast1);
end

