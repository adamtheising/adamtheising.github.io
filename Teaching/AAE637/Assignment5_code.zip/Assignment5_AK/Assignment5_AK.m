%% AAE 637, Spring 2018, Assignment #5
% Charng-Jiun Yu (based on codes from Eduardo Cenci)
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% This code and all accompanying functions are based on previous solutions by:
% Andrew Schreiber, and Brian Gould (main functions)
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

clear;					    % command to clear memory 
clc;                        % command to clear the command window
clear global;               % clear global variables from memory;

%% Setup

% clear previous log file and start it
delete('question1.txt') 
diary('question1.txt');
diary on;

% declare global variables
global numobs do_step critic_limit iter_limit dh func_name depvar rhsvar ...
       numc parnames rhsres parnames_res hetvar hetnames;
 
% read data
[data,txt,~] = xlsread('RECS_Assign_5_18','sheet1');  

data(~any(data(:,3)==1 | data(:,3)==2 | data(:,3)==3, 2),:) = [];
data(~any(data(:,9)==1,2),:) = [];

% change occurence -2 ("not aplicable") in dataset for missing (NaN)
data(data == -2) = NaN;

% extract variables from data
DOEID = data(:,1);
DIVISION = data(:,2);
TYPEHUQ = data(:,3);
HDD30YR = data(:,4);
CDD30YR = data(:,5);
METMIC = data(:,6);
KOWNRENT = data(:,7);
YEARMADE = data(:,8);
HEATHOME = data(:,9);
FUELHEAT = data(:,10);
ADQINSUL = data(:,11);
EDUCATION = data(:,12);
HHAGE = data(:,13);
INCOME = data(:,14);

%% Generate subsample

NEWENG = (DIVISION==1).*1; % (multiply variables by one to convert logical to double)
MA = (DIVISION==2).*1;
ENC = (DIVISION==3).*1;
WNC = (DIVISION==4).*1;
MOUNT = (DIVISION==8 | DIVISION==9 ).*1;
PACIFIC = (DIVISION==10).*1;
METRO = (METMIC==1).*1;
MICRO = (METMIC==2).*1;
HDD302 = HDD30YR/1000;
CDD302 = CDD30YR/1000;
HDDCDD = HDD302.*CDD302;
HOUSEAGE = 2009-YEARMADE;
OWN = (KOWNRENT==1).*1;
MOBILE = (TYPEHUQ==1).*1;

% define vectors y, X and Z
depvar = (FUELHEAT==3).*1;
rhsvar = horzcat(ones(length(depvar),1),NEWENG,MA,ENC,WNC,PACIFIC,MOUNT,METRO, ...
    MICRO,HDD302,CDD302,HDDCDD,HOUSEAGE,OWN,MOBILE);
hetvar = horzcat(INCOME,HDD302,HOUSEAGE./10,NEWENG);

vars_X = {'CONSTANT','NEWENG', 'MA', 'ENC', 'WNC', 'PACIFIC', 'Mount', 'METRO', 'MICRO',...
          'HDD302', 'CDD302', 'HDDCDD', 'HOUSEAGE', 'OWN', 'MOBILE'};
vars_Z = {'INCOME_het', 'HDD302_het', 'HOUSEAGE_het', 'NEWENG_het'};

% parameter names
parnames = char(vars_X);
hetnames = char(vars_Z);

%% Question 1(a) - Estimate the probit model
clear vars_X vars_Z;
             
% Starting values from CRM
b_ini = (rhsvar'*rhsvar)\(rhsvar'*depvar); 

% declare funcional form for MLE
func_name = ('probit_llf');

% setttings for MLE:
[numobs,numc] = size(rhsvar);
critic_limit  = 1e-7;
iter_limit    = 500;   
do_step       = 1;
dh            = 1e-7;

% type I error probability (significance level for post estimation)
alpha = 0.05;                         

% run MLE using BHHH for probit model
[b_prob,c_prob,llf] = probit_bwg(b_ini);

% unrestricted LLF
llf_u = llf;

%% Test if exogenous variables are jointly significant by estimating the restricted model

% (1) First way: estimate the restricted model

numc_full = numc; % store number of parameters for the full model

func_name = ('probit_llf_res');
rhsres = rhsvar(:,1);
[~,nl] = size(parnames);
parnames_res = parnames(1, 1:nl);
[~,numc] = size(rhsres);

% initial values for betas
b_ini_res = (rhsres'*rhsres)\(rhsres'*depvar);

% run MLE using BHHH for restricted probit model
[~,~,llf] = probit_bwg_res(b_ini_res);

% restricted LLF
llf_r = sum(llf);

% perform likelihood ratio test
l_ratio = 2*(llf_u - llf_r);
fprintf('\nThe likelihood ratio value is: %4.4f\n', l_ratio);
crit = chi_bwg(alpha,numc_full-numc,l_ratio);

% (2) Second way: Use the formula from lecture slide "qualitative_2_12",
% page 28

ybar = mean(depvar);
llf_r = numobs*(ybar*log(ybar)+(1-ybar)*log(1-ybar));

% perform likelihood ratio test
l_ratio = 2*(llf_u - llf_r);
fprintf('\nThe likelihood ratio value is: %4.4f\n', l_ratio);
crit = chi_bwg(alpha,numc_full-numc,l_ratio);


%% Question 1(b).i - Test the impact of geographic locations:
% NewEng, MA, ENC, WNC, Pacific, and Mount (columns 2-7)
func_name = ('probit_llf_res');
rhsres = rhsvar(:,[1 8:15]);
[~,nl] = size(parnames);
parnames_res = parnames([1 8:15], 1:nl);
[numobs,numc] = size(rhsres);

% initial values for betas
b_ini_res = (rhsres'*rhsres)\(rhsres'*depvar);

% run MLE using BHHH for restricted probit model
[~,~,llf] = probit_bwg_res(b_ini_res);

% restricted LLF
llf_r = sum(llf);

% perform likelihood ratio test
l_ratio = 2*(llf_u - llf_r);
fprintf('\nThe likelihood ratio value is: %4.4f\n', l_ratio);
crit = chi_bwg(alpha,numc_full-numc,l_ratio);

% re-initialize number of obs and parameters
[numobs,numc] = size(rhsvar);
%% Question 1(b).ii - Calculate the discrete change effect for Mobile
diff = disc_mobile(b_prob);
fprintf('\nThe average discrete change effect for dummy Mobile is: %8.4f\n', diff);

% Delta Method to obtain variance of discrete change effect
diff_der = Grad(b_prob,'disc_mobile',1);
diff_cov = diff_der * c_prob * diff_der';

% compute the Z-value
zstat = (diff - 0)/sqrt(diff_cov);
fprintf('\nThe z-stat for testing discrete change = 0 is %8.4f \n',...
        zstat);
    
%% Question 1(b).iii - Calculate and test the marginal effect of HDD302 
diff = marg_hdd(b_prob);
fprintf('\nThe average marginal effect of HDD302 is: %8.4f\n', diff);

% Delta Method to obtain variance of discrete change effect
diff_der = Grad(b_prob,'marg_hdd',1);
diff_cov = diff_der * c_prob * diff_der';

% perform t-test
tstat = (diff - 0)/sqrt(diff_cov);
pvalue = 2*(1-tcdf(abs(tstat),numobs-numc));
fprintf('\nThe t-stat for testing marginal effect of HDD302 = 0 is %8.4f (p-value = %5.4f)\n',...
        tstat, pvalue);
if pvalue<0.05
    disp('Reject H_0 under 0.05 significance level');
else
    disp('Fail to reject H_0 under 0.05 significance level');
end

%% Question 1(b).iv - Test the significance of average interaction effect of HDD302 and CDD302
diff = iter_effect(b_prob);
fprintf('\nThe average interaction effect of HDD302 and CDD302 is: %8.4f\n', diff);

% Delta Method to obtain variance of discrete change effect
diff_der = Grad(b_prob,'iter_effect',1);
diff_cov = diff_der * c_prob * diff_der';

% perform t-test
tstat = (diff - 0)/sqrt(diff_cov);
pvalue = 2*(1-tcdf(abs(tstat),numobs-numc));
fprintf('\nThe t-stat for testing interaction effect of HDD302 and CDD302 = 0 is %8.4f (p-value = %5.4f)\n',...
        tstat, pvalue);
if pvalue<0.05
    disp('Reject H_0 under 0.05 significance level');
else
    disp('Fail to reject H_0 under 0.05 significance level');
end


%% Question 1(c) - Calculate the average elasticity of HDD302
diff = elast_hdd(b_prob);
fprintf('\nThe average elasticity of HDD302 is: %8.4f\n', diff);

% Delta Method to obtain variance of discrete change effect
diff_der = Grad(b_prob,'elast_hdd',1);
diff_cov = diff_der * c_prob * diff_der';

% perform t-test
tstat = (diff - 0)/sqrt(diff_cov);
pvalue = 2*(1-tcdf(abs(tstat),numobs-numc));
fprintf('\nThe t-stat for testing average elasticity of HDD302 = 0 is %8.4f (p-value = %5.4f)\n',...
        tstat, pvalue);
if pvalue<0.05
    disp('Reject H_0 under 0.05 significance level');
else
    disp('Fail to reject H_0 under 0.05 significance level');
end

%% Question 1(d) - Calculate the average elasticity of HouseAge
e_avg = elast_hage_avg(b_prob);
fprintf('\nThe average elasticity of HouseAge is: %8.4f\n', e_avg);

% calculate the elasticity of HouseAge at the mean of the data
e_mean = elast_hage_mean(b_prob);
fprintf('\nThe elasticity of HouseAge at the mean of the data is: %8.4f\n', e_mean);

% calculate their difference
diff = elast_hage_diff(b_prob);
fprintf('\nThe difference of these two elasticities is: %8.4f\n', diff);

% Delta Method to obtain variance of discrete change effect
diff_der = Grad(b_prob,'elast_hage_diff',1);
diff_cov = diff_der * c_prob * diff_der';

% perform t-test
tstat = (diff - 0)/sqrt(diff_cov);
pvalue = 2*(1-tcdf(abs(tstat),numobs-numc));
fprintf('\nThe t-stat for testing equal elasticities is %8.4f (p-value = %5.4f)\n',...
        tstat, pvalue);
if pvalue<0.05
    disp('Reject H_0 under 0.05 significance level');
else
    disp('Fail to reject H_0 under 0.05 significance level');
end

clear b_ini a_ini p_ini;
diary off;

%% Question 2(a) - Estimate heteroskedastic model
% clear previous log file and start it
delete('question2.txt') 
diary('question2.txt');
diary on;

% starting values
b_ini = b_prob;
g_ini = [.01, .01, .01, 0.01]';
p_ini = vertcat(b_ini, g_ini);

names = char(parnames,hetnames);

% declare funcional form for MLE
func_name = ('probit_hetero_llf');

% setttings for MLE:
[numobs,numc] = size(rhsvar);
critic_limit  = 1e-6;
iter_limit    = 500;   
do_step       = 1;
dh            = 1e-7;

[b_phet,c_phet,llf_het] = max_bhhh(p_ini,names); 

% unrestricted LLF (het.)
llf_het_u = sum(llf_het);

% perform likelihood ratio test
l_ratio = 2*(llf_het_u - llf_u);
fprintf('\nThe likelihood ratio value is: %4.4f\n', l_ratio);
crit = chi_bwg(alpha,length(b_phet)-length(b_prob),l_ratio);
disp('');

%% Question 2(b) - Compute average elasticity of HDD302 using the heteroskedastic model
diff = elast_hdd_het(b_phet);
fprintf('\nThe average elasticity of HDD302 is: %8.4f\n', diff);

% Delta Method to obtain variance of discrete change effect
diff_der = Grad(b_phet,'elast_hdd_het',1);
diff_cov = diff_der * c_phet * diff_der';
diff_se = sqrt(diff_cov);
fprintf('\nThe s.e. for the average elasticity of HDD302 is: %8.4f\n', diff_se);

% perform t-test (elasticity = 0)
tstat = (diff - 0)/sqrt(diff_cov);
pvalue = 2*(1-tcdf(abs(tstat),numobs-numc));
fprintf('\nThe t-stat for testing average elasticity of HDD302 = 0 is %8.4f (p-value = %5.4f)\n',...
        tstat, pvalue);
if pvalue<0.05
    disp('Reject H_0 under 0.05 significance level');
else
    disp('Fail to reject H_0 under 0.05 significance level');
end
    
%% end of code
diary off;