%{
********************************************************************
********************************************************************
**  This is a maximum likelihood program to estimate a homoskedastic 
**  tobit model 
*********************************************************************
*********************************************************************
%}
clc;                             % Command to clear command window
global critic_limit iter_limit rhsvar numobs do_step func_name dh ...
    parname depend mean_rhs num_above numparm bhhh ... 
    dum_above_lim elasvar;
%delete('t:\tobit.out');       % Delete the previous output
[base_data,varnames,raw] = xlsread('cheese_only_data_v2'); % Load excel data 
%diary('t:\tobit.out');
[numobs,numc]=size(base_data);  % Determine size of full data matrix
%************* Read in all the data ***************
HHSIZE = base_data(:,2);
INCOMET = base_data(:,3);
TCHZX = base_data(:,4);
TCHZQ = base_data(:,5);
SM_CITY = base_data(:,7);
CITY = base_data(:,8);
PERLT6 = base_data(:,9);
PER6_11 = base_data(:,10);
PERG66 = base_data(:,11);
P_CHZ = base_data(:,12);

PC_TCHZQ = TCHZQ./HHSIZE;
rhsvar=horzcat(ones(numobs,1),P_CHZ,INCOMET, SM_CITY,...
    CITY,HHSIZE,PERLT6,PER6_11,PERG66);
depend=PC_TCHZQ;   % Identify dep. var 
parname=char({'CONSTANT','P_CHZ', 'INCOMET', 'SM_CITY','CITY', ...
          'HHSIZE', 'PERLT6', 'PER6_11', 'PERG66','SIGMA'});          %*** Col. vector of param. names ***
critic_limit=1e-6;            % Critical % change in parameters
iter_limit=3000;               % Maximum number of iterations
do_step=1;                    % =1 variable step length, 0 fixed 
func_name =('tobit_llf');     % Identify LLF function
alpha=.05;                    % Type I Error Probability 
dh = 0.000001;
bhhh=1;
dum_above_lim=depend > 0; 
index=find(dum_above_lim);
num_above=sum(dum_above_lim);  %*** Number of Noncensored Obs. ***
%*********** Calculate Elasticities for these variables ************
elasvar=1;                     %*** Pick Variable for Marginal ***
elasvar=elasvar+1;             %*** Add 1 due to constant term ***
%*****************************************************
%*  Obtain the OLS estimates using all the data and **
%*  ignoring the truncated nature of the dependent  **
%*  variable.                                       **
%*****************************************************
bls = (rhsvar'*rhsvar)\(rhsvar')*depend;
df = numobs - length(bls);
ehat = depend - rhsvar*bls;
sse = ehat'*ehat;
sighat = sse/df;
covb = sighat.*inv(rhsvar'*rhsvar);
stbls = sqrt(diag(covb));
fprintf('The Percent of OBS with Zeros:  %5.4f', ...
                            (1-(num_above/numobs))*100);

disp('Now the Tobit Iterations Start');  
disp('  ');   
b0=vertcat(bls,sighat);    %***Use CRM Results for Starting Values ***
numparm=length(b0);        %*** No. of Est. Coef. including sigmasq***

[b_tobit,covb_tobit,tobit_llf_vec] =  max_bhhh(b0,parname);
