function [output] = cond_elas(b0)
global sigma rhsvar

rhsvar_mean = mean(rhsvar);
mu_mean = rhsvar_mean*b0(1:9,1);
lambda_mean = normpdf(mu_mean./sigma)./normcdf(mu_mean./sigma);

output = b0(2).*(1-(mu_mean./sigma).*(normpdf(mu_mean./sigma)./normcdf(mu_mean./sigma))-(normpdf(mu_mean./sigma).^2./normcdf(mu_mean./sigma).^2)) ...
    .*(rhsvar_mean(1,2)./(mu_mean+sigma.*lambda_mean));
end