%***** Run this program after obtaining the homoskadastic estimates

global rhsvar mu sigma lambda 
%% 2(a)

% Store the unrestricted estimates for later use
rhsvar_full = rhsvar;
parname_full = parname;

% Estimate the restricted model with only intercept (and sigma)
rhsvar = rhsvar(:,1);
parname=char({'CONSTANT'});  
bls_res = (rhsvar'*rhsvar)\(rhsvar')*depend;
b0=vertcat(bls_res,sighat);

[b_tobit_res,covb_tobit_res,tobit_llf_vec_res] =  max_bhhh(b0,parname);

% Likelihood for the unrestricted model
llf_homo = sum(tobit_llf_vec);

% Likelihood for the restricted model
llf_res = sum(tobit_llf_vec_res);

% Likelihood ratio test
l_ratio = 2*(llf_homo - llf_res);
fprintf('\nThe likelihood ratio value is: %4.4f\n', l_ratio);
crit = chi_bwg(0.05,8,l_ratio);

% Reset back to the unrestricted estimates

rhsvar = rhsvar_full;
parname = parname_full;
%% 2(b)

sigma = sighat;
mu = rhsvar*b_tobit(1:9,1);
lambda = normpdf(mu./sigma)./normcdf(mu./sigma);
predicted = mu+sigma.*lambda;

depend_cond = depend(depend(:,1)>0);
predicted_cond = predicted(depend(:,1)>0,:);
depend__cond= horzcat(depend_cond,predicted_cond);
index_nan = find(isnan(predicted_cond));
predicted_cond(index_nan,:)=[];
depend_cond(index_nan,:)=[];
depend_predicted= horzcat(depend_cond,predicted_cond);
corr_cond = corrcoef(depend_cond,predicted_cond);

%% 2(c)

% Purchase probability
purchase_elasticity = purchase_elas(b_tobit);

grad_purchase = Grad(b_tobit,'purchase_elas',1);
var_purchase = grad_purchase * covb_tobit * grad_purchase';
se_purchase = var_purchase^0.5;

% perform t-test
tstat = purchase_elasticity/se_purchase;
pvalue = 2*(1-tcdf(abs(tstat),numobs-10));
fprintf('\nThe t-stat for price elasticity on purchase probability = 0 is %8.4f (p-value = %5.4f)\n',...
        tstat, pvalue);
if pvalue<0.05
    disp('Reject H_0 under 0.05 significance level');
else
    disp('Fail to reject H_0 under 0.05 significance level');
end

% Unconditional quantity
unconditional_elasticity = uncond_elas(b_tobit);

grad_uncond = Grad(b_tobit,'uncond_elas',1);
var_uncond = grad_uncond * covb_tobit * grad_uncond';
se_uncond = var_uncond^0.5;

% perform t-test
tstat = unconditional_elasticity/se_uncond;
pvalue = 2*(1-tcdf(abs(tstat),numobs-10));
fprintf('\nThe t-stat for price elasticity on unconditional quantity = 0 is %8.4f (p-value = %5.4f)\n',...
        tstat, pvalue);
if pvalue<0.05
    disp('Reject H_0 under 0.05 significance level');
else
    disp('Fail to reject H_0 under 0.05 significance level');
end

% Conditional quantity
conditional_elasticity = cond_elas(b_tobit);

grad_cond = Grad(b_tobit,'cond_elas',1);
var_cond = grad_cond * covb_tobit * grad_cond';
se_cond = var_cond^0.5;

% perform t-test
tstat = conditional_elasticity/se_cond;
pvalue = 2*(1-tcdf(abs(tstat),numobs-10));
fprintf('\nThe t-stat for price elasticity on conditional quantity = 0 is %8.4f (p-value = %5.4f)\n',...
        tstat, pvalue);
if pvalue<0.05
    disp('Reject H_0 under 0.05 significance level');
else
    disp('Fail to reject H_0 under 0.05 significance level');
end
%% 2(d)

income_elasticity = income_elas(b_tobit);

grad_income = Grad(b_tobit,'income_elas',1);
var_income = grad_income * covb_tobit * grad_income';
se_income = var_income^0.5;

% perform t-test
tstat = (income_elasticity-1)/se_income;
pvalue = (1-tcdf(tstat,numobs-10)); % One-tail
fprintf('\nThe t-stat for uconditional income elasticity = 1 is %8.4f (p-value = %5.4f)\n',...
        tstat, pvalue);
if pvalue<0.05
    disp('Reject H_0 under 0.05 significance level');
else
    disp('Fail to reject H_0 under 0.05 significance level');
end

%% 2(e)
%***** Run this part after obtaining the heteroskedastic estimates
llf_homo = sum(tobit_llf_vec);
llf_heter = sum(tobit_llf_vec_heter);

l_ratio = 2*(llf_homo - llf_heter);
fprintf('\nThe likelihood ratio value is: %4.4f\n', l_ratio);
crit = chi_bwg(0.05,2,l_ratio);