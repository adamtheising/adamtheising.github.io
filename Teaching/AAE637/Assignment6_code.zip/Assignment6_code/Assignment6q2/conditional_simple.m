%{
****************************************************************
*** Program Designed to Estimate the Conditional Logit Model ***
****************************************************************
 %}   
clear;					         % Command to clear memory 
clc;                             % Command to clear command window
global critic_limit iter_limit rhsvar numobs do_step func_name dh ...
    parname numc nalts num_ind mode_id mode mean_mode mode_name ...
    numvar mean_mat weight;
delete('t:\tran_mode.out');       % Delete the previous output
[base_data,varnames,raw] = xlsread('t:\table_f_21_2'); % Load excel data 
diary('t:\tran_mode.out');
[numobs,numc]=size(base_data);  % Determine size of full data matrix
%{
****************** Full data set  *********************************
******* Note the Number of Obs. is nalts*number of orig. obs. *****
*******************************************************************
%}
base_var={'GC','T_TIME'};
mode_var={'MODE'};	               %*** Identify Mode Actually Used ***
modeid_var={'MODE_ID'};            %*** Identify Mode Option ***
hhinc_var={'HH_INC'};
tempvar=pull_data(varnames,base_var,base_data);
mode=pull_data(varnames,mode_var,base_data);
mode_id=pull_data(varnames,modeid_var,base_data);
hh_inc=pull_data(varnames,hhinc_var,base_data);
dum_air=mode_id == 1;                 %*** Dummy Variable for Air ***
dum_train=mode_id == 2;               %*** Dummy Variable for Train ***
dum_bus=mode_id == 3;                 %*** Dummy variable for Bus ***
air_hhinc=dum_air.*hh_inc;     %*** Interaction of Air Dummy and HHINC ***
rhsvar=horzcat(tempvar,air_hhinc,dum_air,dum_train,dum_bus);
mode_name={'Air','Train','Bus','Auto'};
parname={'beta_g','beta_t','gamma_H','alpha_air','alp_train','alpha_bus'};
                                %***** Define Parameter Names *****
critic_limit=1e-6;              % Critical % change in parameters
iter_limit=250;                 % Maximum number of iterations
do_step=1;                      % =1 variable step length, 0 fixed 
func_name =('cond_logit_llf');  % Identify LLF function
alpha=.05;                      % Type I Error Probability 
dh = 0.000001;
actual_p=vertcat(0.14,0.13,0.09,0.64);	%*** Pop. choice probability ***
numvar=3;                       %*** Number of Variables to est elas.***
b0=vertcat(.45,1,.01,1,1,.1);     %*** Starting Values ***
%************************************************************************
[nalts,nc]=size(unique(mode_id));    %*** Number of Alternatives ***
num_ind=numobs./nalts;               %*** Number of Individuals ***
selected=mode_id(mode==1,:);
for i=1:nalts;                        %*** Sample choice prob. ***
   temp=selected(selected==i,:);
   [numindtemp,nc]=size(temp);
   if i == 1;
      sample_p=numindtemp./num_ind;
   else
      sample_p=vertcat(sample_p,(numindtemp./num_ind));
   end;
end;
weight=actual_p./sample_p;       %*** Weights used in choice prob. ***

%*************************************************************************  
disp('Now the Maximum Likelihood Iterations Begin for Conditional Logit');
numobs=num_ind;
[bp_multi,covbp_multi,llf]=max_bhhh(b0,parname); 
                                %** Call Out the Conditional Logit **
%***Calculate the Hessian Based Parameter Covariance Matrix *****/
func_name='tot_cond_logit_llf';
hessian_cov=inv(-hessian_bwg(func_name,bp_multi));  
                                 %** Hessian Based Cov. Matrix **
se_hess=sqrt(diag(hessian_cov));
tvalue2=bp_multi./se_hess;
df2= num_ind-length(b0);               % Degrees of freedom for t-value
pvalue2=2*(1-tcdf(abs(tvalue2),df2));  % Column vector of param p-values 
results2=horzcat(bp_multi,se_hess,tvalue2,pvalue2);
disp('  ');
disp('*****Conditional Logit Results:  Hessian Based Cov *****');
table_bwg(parname,results2,1);

%******************Est.Elasticity Effects *******************
for j=1:nalts; %****Mode Specific Means ****
  mode_var=rhsvar(mode_id == j,:);
  if j == 1;
     mean_mode=mean(mode_var)';
  else
     mean_mode=horzcat(mean_mode,mean(mode_var)');
  end;
end;
denom=0;
for i=1:nalts;
   rhsvar_i=rhsvar(mode_id == i,:);   
   mean_rhs=mean(rhsvar_i);
   denom=denom+exp(mean_rhs*bp_multi);
   if i == 1;
      mean_mat=mean_rhs;
   else
      mean_mat=vertcat(mean_mat,mean_rhs);
   end;
end;
for i=1:nalts;
   if i == 1;
      est_prob=exp(mean_mat(i,:)*bp_multi)./denom;
   else
      est_prob=vertcat(est_prob,(exp(mean_mat(i,:)*bp_multi)./denom));
   end; 	
end;  
  
   for j=1:nalts;
     for k=1:nalts;
      for i=1:numvar;
      	if (j == k);
            elas_effects=mean_mode(i,k).*(1-est_prob(k)).*bp_multi(i);                                                  %****Greene p. 846****/
        else
            elas_effects=mean_mode(i,k).*(-est_prob(k)).*bp_multi(i);
        end;
        if i == 1;
            elas_effects1(k,j)=elas_effects;
        elseif i == 2;
            elas_effects2(k,j)=elas_effects;
        elseif i == 3;
            elas_effects3(k,j)=elas_effects;
        end;                
      end;      
     end;
   end;

disp('This is the elas. effect of Mode Cost on Mode Choice Prob.');
disp('******************************************************');
table_bwg(mode_name,elas_effects1,5);
disp('******************************************************'); 
disp('This is the elas. effect of Term. Time on Mode Choice Prob.');
disp('******************************************************');
table_bwg(mode_name,elas_effects2,5);
disp('******************************************************'); 
disp('This is the elas. effect of Air_D*Inc on Mode Choice Prob.');
disp('******************************************************');
table_bwg(mode_name,elas_effects3,5);
disp('******************************************************');

%*** Call Out the Conditonal Logit, Choice Based Sampling ***
func_name='weighted_cond_logit_llf';
disp('The following are the Weighted LLF Results');
[bp_multi_w,covbp_multi_w,w_llf]=max_bhhh(bp_multi,parname); 
%***Calculate the Hessian Based Parameter Covariance Matrix ***
func_name='tot_w_cond_logit_llf';
hessian_cov_w=inv(-hessian_bwg(func_name,bp_multi_w));  
se_hess_w=sqrt(diag(hessian_cov_w));
tvalue_hess=bp_multi_w./se_hess_w;
%****** Building Robust Covariance Matrix, p. 711 Greene ******
hessian_c=inv(hessian_bwg(func_name,bp_multi_w)); %** Weighted Hessian **
%************ Create Cap B ************
func_name='weighted_cond_logit_llf';
weight=sqrt(weight);
zz = Grad(bp_multi_w,func_name,num_ind);
cap_b=zz'*zz;                           %*** cap B p.711 ***
robust_cov=hessian_c*cap_b*hessian_c;   %*** Robust Cov Matrix ***
se_robust=sqrt(diag(robust_cov));
results_w=horzcat(bp_multi_w,se_hess_w,(bp_multi_w./se_hess_w), ...
           se_robust,(bp_multi_w./se_robust));
disp('***********Conditional Logit Results:  Choice Weights*********');
table_bwg(parname,results_w,6);
diary off;
