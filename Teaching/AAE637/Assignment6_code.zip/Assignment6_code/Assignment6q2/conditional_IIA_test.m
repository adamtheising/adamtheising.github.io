%{
****************************************************************
*** Program Designed to Estimate the Conditional Logit Model ***
****************************************************************
 %}   
clear;					         % Command to clear memory 
clc;                             % Command to clear command window
global critic_limit iter_limit rhsvar numobs do_step func_name dh ...
    parname numc nalts num_ind mode_id mode mean_mode mode_name ...
    numvar mean_mat;
delete('t:\iia.out');       % Delete the previous output
[base_data,varnames,raw] = xlsread('t:\table_f_21_2'); % Load excel data 
diary('t:\iia.out');
%{
****************** Full data set  *********************************
******* Note the Number of Obs. is nalts*number of orig. obs. *****
*******************************************************************
%}
base_var={'GC','T_TIME'};
mode_var={'MODE'};	            %*** Identify Mode Actually Used ***
modeid_var={'MODE_ID'};         %*** Identify Mode Option ***
hhinc_var={'HH_INC'};
tempvar=pull_data(varnames,base_var,base_data);
mode=pull_data(varnames,mode_var,base_data);
mode_id=pull_data(varnames,modeid_var,base_data);
hh_inc=pull_data(varnames,hhinc_var,base_data);
dum_air=mode_id == 1;          %*** Dummy Variable for Air ***
dum_train=mode_id == 2;        %*** Dummy Variable for Train ***
dum_bus=mode_id == 3;          %*** Dummy variable for Bus ***
air_hhinc=dum_air.*hh_inc;     %*** Interaction of Air Dummy and HHINC ***
rhsvar=horzcat(tempvar,air_hhinc,dum_air,dum_train,dum_bus);
%*****************Omit Airplane Choice ******************
rhsvar_2=tempvar(dum_air ==0,:);   %*** Omit Airplane as an option ***
dum_train_2=dum_train(dum_air ==0,:);
dum_bus_2=dum_bus(dum_air == 0,:);
mode_id2=mode_id(dum_air== 0,:);
mode2=mode(dum_air==0,:);
rhsvar_2=horzcat(rhsvar_2,dum_train_2,dum_bus_2);
mode_name={'Air','Train','Bus','Auto'};
parname={'beta_g','beta_t','gamma_H','alpha_air','alp_train','alpha_bus'};
parname2={'beta_g','beta_t','alp_train','alpha_bus'};
                                %***** Define Parameter Names *****
critic_limit=1e-6;              % Critical % change in parameters
iter_limit=250;                 % Maximum number of iterations
do_step=1;                      % =1 variable step length, 0 fixed 
func_name =('cond_logit_llf');  % Identify LLF function
alpha=.05;                      % Type I Error Probability 
dh = 0.000001;
b0=vertcat(.15,.2,.01,5,3.5,3.2);     %*** Starting Values ***
%************************************************************************
[numobs,numc]=size(base_data);  % Determine size of full data matrix
[nalts,nc]=size(unique(mode_id));    %*** Number of Alternatives ***
num_ind=numobs./nalts;               %*** Number of Individuals ***
%*************************************************************************  
disp('Now the Maximum Likelihood Iterations Begin for Conditonal Logit');
numobs=num_ind;
[bp_multi,covbp_multi,llf]=max_bhhh(b0,parname); 
                                %** Call Out the Conditional Logit **
%***Calculate the Hessian Based Parameter Covariance Matrix *****/
func_name='tot_cond_logit_llf';
hessian_cov=inv(-hessian_bwg(func_name,bp_multi));  
                                 %** Hessian Based Cov. Matrix **
se_hess=sqrt(diag(hessian_cov));
tvalue2=bp_multi./se_hess;
df2= num_ind-length(b0);               % Degrees of freedom for t-value
pvalue2=2*(1-tcdf(abs(tvalue2),df2));  % Column vector of param p-values 
results2=horzcat(bp_multi,se_hess,tvalue2,pvalue2);
disp('  ');
disp('*****Conditional Logit Results:  Hessian Based Cov *****');
table_bwg(parname,results2,1);
%************** Testing for IIA *******************
IIA_cov_orig=hessian_cov([1 2 5 6], [1 2 5 6]); 
                              %** Select Elements from Orig. Cov Matrix **
IIA_beta_orig=bp_multi([1 2 5 6]); %*** Select Orginal Betas ***
rhsvar=rhsvar_2;			  %*** Make RHS Matrix the Restricted one ***
mode_id=mode_id2;			  %*** Made Mode ID the Restricted one ***
mode_id=mode_id-1;            %*** Adjust Mode ID ***
nalts=nalts-1;                %*** Adjust Alternative Count ***
mode=mode2;					  %*** Made Mode the restricted mode ***
[numobs,numc]=size(rhsvar_2);  % Determine size of full data matrix
num_ind=numobs./nalts;  
numobs=num_ind;             %*** Number of Individuals ***
func_name=('cond_logit_llf');
[bp_multi2,covbp_multi2,llf2]=max_bhhh(IIA_beta_orig,parname2);
                              %*** Estimate the Restricted Model ***
%**Calculate the Hessian Based Parameter Covariance Matrix**/
func_name='tot_cond_logit_llf';
hessian_cov2=inv(-hessian_bwg(func_name,bp_multi2));  
                                 %** Hessian Based Cov. Matrix **
se_hess22=sqrt(diag(hessian_cov2));
tvalue22=bp_multi2./se_hess22;
df2= num_ind-length(bp_multi2);          % Degrees of freedom for t-value
pvalue22=2*(1-tcdf(abs(tvalue22),df2));  % Column vector of param p-values 
results22=horzcat(bp_multi2,se_hess22,tvalue22,pvalue22);
disp('*****Conditional Logit Results:  Hessian Based Cov *****');
table_bwg(parname2,results22,1); 
diff=bp_multi2-IIA_beta_orig;
chi_square=diff'*inv(hessian_cov2-IIA_cov_orig)*diff;
                    %***** Chi-square Stat, Greene, p.724 ********
fprintf('This is the IIA Chi_square for Air: %6.4f',chi_square); 
disp('  ');
fprintf('Degrees of Freedom:%4.0f', length(bp_multi2)); disp('  ');
chi_sq_critical=chi_bwg(alpha,length(bp_multi2),chi_square);
diary off;