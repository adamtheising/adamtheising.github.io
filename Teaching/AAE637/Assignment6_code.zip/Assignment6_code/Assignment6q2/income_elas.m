function [output] = income_elas(b0)
global sigma rhsvar

rhsvar_mean = mean(rhsvar);
mu_mean = rhsvar_mean*b0(1:9,1);
lambda_mean = normpdf(mu_mean./sigma)./normcdf(mu_mean./sigma);

output = b0(3)*normcdf(mu_mean./sigma).*(rhsvar_mean(1,3)./(normcdf(mu_mean/sigma).*(mu_mean+sigma.*lambda_mean)));
end