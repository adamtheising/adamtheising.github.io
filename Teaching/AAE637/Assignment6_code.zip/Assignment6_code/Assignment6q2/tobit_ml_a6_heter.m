%{
********************************************************************
********************************************************************
**  This is a maximum likelihood program to estimate a heteroskedastic 
**  tobit model. Run this code after obtaining the homoskedastic estimates
*********************************************************************
*********************************************************************
%}
clc;                             % Command to clear command window
global critic_limit iter_limit rhsvar numobs do_step func_name dh ...
    parname depend mean_rhs num_above numparm bhhh hetvar b_tobit ... 
    dum_above_lim elasvar;
%delete('t:\tobit.out');       % Delete the previous output
[base_data,varnames,raw] = xlsread('cheese_only_data_v2'); % Load excel data 
%diary('t:\tobit.out');
[numobs,numc]=size(base_data);  % Determine size of full data matrix
%************* Read in all the data ***************
HHSIZE = base_data(:,2);
INCOMET = base_data(:,3);
TCHZX = base_data(:,4);
TCHZQ = base_data(:,5);
SM_CITY = base_data(:,7);
CITY = base_data(:,8);
PERLT6 = base_data(:,9);
PER6_11 = base_data(:,10);
PERG66 = base_data(:,11);
P_CHZ = base_data(:,12);

PC_TCHZQ = TCHZQ./HHSIZE;

rhsvar=horzcat(ones(numobs,1),P_CHZ,INCOMET, SM_CITY,...
    CITY,HHSIZE,PERLT6,PER6_11,PERG66);
depend=PC_TCHZQ;   % Identify dep. var 
hetvar = horzcat(ones(numobs,1),INCOMET);
parname=char({'CONSTANT','P_CHZ', 'INCOMET', 'SM_CITY', 'CITY', ...
         'HHSIZE', 'PERLT6', 'PER6_11', 'PERG66', 'CONSTANT_het', 'INCOMET_het'});%*** Col. vector of param. names ***
 critic_limit=1e-6;            % Critical % change in parameters
iter_limit=3000;               % Maximum number of iterations
do_step=1;                    % =1 variable step length, 0 fixed 
func_name =('tobit_llf_heter');     % Identify LLF function
alpha=.05;                    % Type I Error Probability 
dh = 0.000001;
bhhh=1;
dum_above_lim=depend > 0; 
index=find(dum_above_lim);
num_above=sum(dum_above_lim);  %*** Number of Noncensored Obs. ***
%*********** Calculate Elasticities for these variables ************
elasvar=1;                     %*** Pick Variable for Marginal ***
elasvar=elasvar+1;             %*** Add 1 due to constant term ***
%*****************************************************
%*  Use the estimaes of homoskedastic tobit as starting values **
%*****************************************************
bls_part1 = b_tobit(1:end-1,:);
bls_part2 = [0.1; 0.1];
bls = vertcat(bls_part1,bls_part2);
df = numobs - length(bls);
fprintf('The Percent of OBS with Zeros:  %5.4f', ...
                            (1-(num_above/numobs))*100);
                        
disp('Now the Tobit Iterations Start');  
disp('  ');   
b0=bls;    %***Use CRM Results for Starting Values ***
numparm=length(b0);        %*** No. of Est. Coef. including sigmasq***
if bhhh ==0;
   [b_tobit_heter,covb_tobit_heter,tot_tobit_llf_heter] =  ...  
           max_NR(b0,parname);  %*** Call Out the NR-Tobit ***
else [b_tobit_heter,covb_tobit_heter,tobit_llf_vec_heter] =  ...       
    max_bhhh(b0,parname);
end;




