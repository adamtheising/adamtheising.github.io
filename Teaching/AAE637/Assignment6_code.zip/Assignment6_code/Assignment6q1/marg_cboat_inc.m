function [marg] = marg_cboat_inc(b0)
  global rhsvar nalts mode_id numobs;   
  beta_i = b0(6);

  % matrix of probabilities
  part1 = zeros(numobs, nalts);
  for r=1:nalts
      rhsvar_r = rhsvar(mode_id==r,:);      
      if isempty(rhsvar_r)
         continue
      end
      part1(:,r) = exp(rhsvar_r*b0); % Tx1 vector in colum r  
  end;
    % calculating exp(XB_ij)/sum(exp(XBi1)+...+exp(XBiJ)) for all j in J = nalts
    divisor = sum(part1, 2); % sums along the dimension 2 (rows)
    for j=1:nalts
      part1(:,j) = part1(:,j)./divisor;
    end
    
  % beach is the 1st choice
  p_1_mat = repmat(part1(:,1), 1, nalts);
  
  % indicator for mth choice 
  indicator = zeros(numobs, 4);
  indicator(:, 1) = 1;
  
  % formula for marginal effects
  marg_i = p_1_mat .* (indicator - part1) .* beta_i;
  marg_i = mean(marg_i);
  
  % charter boat is the 4th choice
  marg   = marg_i(4);
end
