function [ret] = cost_mfx(b0)
global rhsvar nalts numobs mode_id rhs_change;
    
  % (Original) probabilities for baseline RHS vector
  part1 = zeros(numobs, nalts);
  for r=1:nalts
      rhsvar_r = rhsvar(mode_id==r,:);      
      if isempty(rhsvar_r)
         continue
      end
      part1(:,r) = exp(rhsvar_r*b0); % Tx1 vector in colum r  
  end;
    % calculating exp(XB_ij)/sum(exp(XBi1)+...+exp(XBiJ)) for all j in J = nalts
    divisor = sum(part1, 2); % sums along the dimension 2 (rows)
    for j=1:nalts
      part1(:,j) = part1(:,j)./divisor;
    end

  % (Updated) probabilities for RHS vector with increased costs
  part2 = zeros(numobs, nalts);
  for r=1:nalts        
     rhsvar_r = rhs_change(mode_id==r,:);  
     if isempty(rhsvar_r)
        continue
     end
     part2(:,r) = exp(rhsvar_r*b0); % Tx1 vector in colum j
  end;
    % calculating exp(XB_ij)/sum(exp(XBi1)+...+exp(XBiJ)) for all j in J = nalts
    divisor = sum(part2, 2); % sums along the dimension 2 (rows)
    for j=1:nalts
      part2(:,j) = part2(:,j)./divisor;
    end
 
  ret = mean(part2 - part1);   
  
end