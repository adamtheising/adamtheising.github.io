function [elast] = elast_pboat_rate(b0)
  global rhsvar nalts mode_id numobs;   
  beta_c = b0(2);

  % Matrix of probabilities for each observation
  part1 = zeros(numobs, nalts);
  for r=1:nalts
      rhsvar_r = rhsvar(mode_id==r,:);      
      if isempty(rhsvar_r)
         continue
      end
      part1(:,r) = exp(rhsvar_r*b0); % Tx1 vector in colum r  
  end;
    % calculating exp(XB_ij)/sum(exp(XBi1)+...+exp(XBiJ)) for all j in J = nalts
    divisor = sum(part1, 2); % sums along the dimension 2 (rows)
    for j=1:nalts
      part1(:,j) = part1(:,j)./divisor;
    end
    
  % catch rate is the 2nd attribute and private boat is the 3rd choice
  % so x_mk with k = 2 and m = 3 is x_32 
  x_32 = rhsvar(mode_id==3,2); % Take second column of attribute matrix
  x_32_mat = repmat(x_32, 1, nalts); % Repeat once for each alt.
  p_3 = part1(:,3); % Take third column of probability matrix
  p_3_mat = repmat(p_3, 1, nalts); % Repeat once for each alt.
  
  % indicator for mth choice 
  indicator = zeros(numobs, 4); % Set indicator to zero for j != k
  indicator(:, 3) = 1; % Set indicator to 1 for j=k
  
  % formula for elasticity (Greene, 7th ed. p. 806)
  elast_i = x_32_mat .* (indicator - p_3_mat) .* beta_c;
  elast = mean(elast_i);
end
