%% AAE 637, Spring 2018, Assignment #6
% A.E. Theising
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% This code and accompanying functions are based on previous solutions by:
% Travis McArthur and Eduardo Cenci
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

clear;					    % command to clear memory 
clc;                        % command to clear the command window
clear global;               % clear global variables from memory;

delete('assign6q1.txt') 
diary('assign6q1.txt');

%% Question 1:
%  read data
% clear previous log file and start it
% declare global variables
global critic_limit iter_limit do_step dh func_name numobs parnames ...
       depvar rhsvar nalts mode_id mode;
      
[dat,txt,~] = xlsread('new_fish_file.xls');  % read in adjusted dataset
[numr,numc] = size(dat);  

%% Question 1:
%  prepare data

% create dummies for pier, private boat, and charter boat
choice_var = {'CHOICE'};
modeid_var = {'MODE_ID'};
inc_var    = {'INCOME'};
covariates = {'COST','C_RATE'};
mode       = pull_data(txt, choice_var, dat);
mode_id    = pull_data(txt, modeid_var, dat);
income     = pull_data(txt, inc_var,    dat);
covariates = pull_data(txt, covariates, dat);
dum_beach  = mode_id == 1;
dum_pboat  = mode_id == 3;
dum_cboat  = mode_id == 4;

% build rhsvar matrix and declare depvar
rhsvar = horzcat(covariates, dum_beach, dum_pboat, dum_cboat);
depvar = mode;

% number of alternatives and number of observations
[nalts,~] = size(unique(mode_id));
numobs    = numr/nalts;

% parameter names
mode_name  = {'Beach','Pier','P_Boat','C_Boat'};
parnames   = {'Cost','Catch Rate','Beach','P_Boat','C_Boat'};

%% Question 1.a:
% conditional logit estimation

% use CRM to obtain the starting values
% for accuracy and speed, replace inv(A)*b with A\b
b_ini = (rhsvar'*rhsvar)\(rhsvar'*depvar); 

% print starting values:
disp(' ');
disp('Starting values calculated from OLS:');
fprintf('B1:  %2.4f, B2:  %2.4f, B3:  %2.4f, B4:  %2.4f, B5: %2.4f\n', ...
         b_ini(1),   b_ini(2),   b_ini(3),   b_ini(4),   b_ini(5));
disp(' ');

% declare funcional form for MLE
func_name = ('cond_logit_llf');

% setttings for MLE:
critic_limit = 1e-7;
iter_limit   = 500;
do_step      = 1;
dh           = 1e-7;

% type I error probability (significance level for post estimation)
alpha        = .05;

% run MLE using BHHH for conditional logit model
disp('Conditional Logit Estimation');
[b_cond,c_cond,llf] = max_bhhh(b_ini,parnames);

% unrestricted LLF
llf_u = sum(llf);

% calculate likelihood ratio index, or McFadden's (Greene 7th ed. p. 805)
llf_r = - numobs .* log(nalts); % total LLF with no exogenous vars => XB = 0
r_lri = 1 - (llf_u/llf_r);

fprintf('\nThe likelihood ratio index (McFadden''s) is:  %2.4f\n', r_lri);

clear llf_r r_lri
%% Question 1.b:
% IIA test
disp('Hausman IIA test:');
disp(' ');

% Calculate the Hessian based var-cov matrix for the unrestricted model
func_name = 'tot_cond_logit_llf';
hess_varcov = inv(-hessian_bwg(func_name,b_cond));

% Adjust global variables; save unrestricted data for next sections:
removal_index = mode_id == 1; % Want to drop beach alternative to test IIA
covariates2      = covariates(removal_index==0,:);       %Eliminate charter boat choice
dum_pboat2  = dum_pboat(removal_index==0,:);
dum_cboat2  = dum_cboat(removal_index==0,:);
mode_id_old = mode_id;
choice_old  = mode;
rhsvarold   = rhsvar;
mode_id     = mode_id(removal_index==0) - 1; % Options 1, 2 & 3 now.
rhsvar      = horzcat(covariates2,dum_pboat2,dum_cboat2);
mode        = mode(removal_index==0); % No beach option
depvar      = mode;

% Mode and rhsvar names.
mode_name  = {'Pier','P_Boat','C_Boat'};
parnames   = {'Cost','Catch Rate','P_Boat','C_Boat'};

% number of alternatives and number of observations
[nalts,~] = size(unique(mode_id));
[numr,~] = size(mode_id);
numobs    = numr/nalts;

%Run the restricted model
b_ini = (rhsvar'*rhsvar)\(rhsvar'*depvar);
func_name = 'cond_logit_llf';
disp('Restricted Conditional Logit (no beach choice)');
[b_res,c_res,llf_res] = max_bhhh(b_ini,parnames);

% Calculate Hessian-based var-cov matrix for restricted model
func_name       = 'tot_cond_logit_llf';
hess_varcov_res = inv(-hessian_bwg(func_name,b_res));

% Generate the statistic for the Hausman IIA test
df         = numel(b_res);  %degrees of freedom= # of params in restricted model 
pardiff    = b_res-b_cond([1 2 4 5]);
varcovdiff = hess_varcov_res-hess_varcov([1 2 4 5],[1 2 4 5]);
Chi2stat   = pardiff'*inv(varcovdiff)*pardiff;  %Calculate Chi Sq statistic

disp('IIA test for beach choice:');  
fprintf('Chi-square statistic: %4.4f\r',Chi2stat);
fprintf('Degrees of freedom: %4.0f\r',df);
chi2crit=chi_bwg(alpha,df,Chi2stat);    %Run the test
disp(' ');

%%
% Reset back to unrestricted values.
rhsvar  = rhsvarold;   
mode_id = mode_id_old;
mode    = choice_old;
depvar = mode;
[nalts,~] = size(unique(mode_id));
[numr,~] = size(mode_id);
numobs    = numr/nalts;

%% Question 1.c:
% Average marginal effects of cost change for each alternative

cond_logit_llf(b_cond);
%cost_mfx(params)

global rhs_change

% This loop adds $100 to the cost of alternative j and backs out the
% average marginal effects on the probability of choice for each
% alternative. It should return a 4x4 matrix.
mfx_mat = zeros(4, 4);
for target_mode=1:4
    rhs_change = rhsvar;
    rhs_change(mode_id==target_mode, 1) = rhs_change(mode_id==target_mode, 1) + 1;
    mfx_mat(:, target_mode) = cost_mfx(b_cond);
end

disp('This is the matrix of average marginal responses:')
mfx_mat
disp('(element D_jr refer to the change in the probability of choosing mode j');
disp('when there is a $100 increase in the cost of mode r)');
 
% This loop calculates respective standard errors for each of the marginal
% effects, then outputs a T-stat table:
mfx_se_mat = zeros(4, 4);
for target_mode=1:4
    rhs_change = rhsvar;
    rhs_change(mode_id==target_mode, 1) = rhs_change(mode_id==target_mode, 1) + 1;
    mfx_grad = Grad(b_cond, 'cost_mfx', 4); % NOTE THE "4"
    mfx_V_hat = mfx_grad * c_cond * mfx_grad' ;
    mfx_se_mat(:, target_mode) = diag(sqrt(mfx_V_hat));
end

% T-stats
disp('   ');
disp('This is the matrix of t-stats for the marginal responses');
mfx_mat ./ mfx_se_mat

clear mfx_mat mfx_se_mat mfx_V_hat rhs_change

%% Question 1.d:
% Average elasticity change in private boat catch rate
elast_1d = elast_pboat_rate(b_cond);
elast_1d_grad = Grad(b_cond, 'elast_pboat_rate', 4); % NOTE THE "4"
elast_1d_vcv = elast_1d_grad * c_cond * elast_1d_grad';
elast_tstats = diag(elast_1d ./ diag(sqrt(elast_1d_vcv)))';

disp('    ');
disp('Probability elasts for change in private boat catch rate are:');
elast_1d
disp('Respective t-stats are:');
elast_tstats

disp('Testing whether elasticity of P_boat = - elasticity of C_boat');
R    = [0,0,1,1]; %Compare private and charter elast
W    = (R*elast_1d')'*(R*elast_1d_vcv*R')^-1*(R*elast_1d');
df   = 1;
pval = 1-chi2cdf(W,df);

fprintf('Wald statistic is equal to: %10.4f \n',W);
if pval<0.05
    disp('Reject H_0');
else
    disp('Fail to reject H_0');
end
fprintf('\n');  

clear elast_1d elast_1d_grad elast_1d_vcv elast_tstats R W df pval
%% Question 1.e:
mean1 = mean(income(mode==1 & mode_id==1));
sd1 = std(income(mode==1 & mode_id==1));
mean2 = mean(income(mode==1 & mode_id==2));
sd2 = std(income(mode==1 & mode_id==2));
mean3 = mean(income(mode==1 & mode_id==3));
sd3 = std(income(mode==1 & mode_id==3));
mean4 = mean(income(mode==1 & mode_id==4));
sd4 = std(income(mode==1 & mode_id==4));
disp('   ')
disp('Mean income conditional on mode used:')
fprintf('------------------------------------------------\n')
fprintf('    Mode             Mean            Std. Dev    \n')
fprintf('------------------------------------------------\n')
fprintf('    Beach        %10.4f        %10.4f  \n', mean1, sd1)
fprintf('    Pier         %10.4f        %10.4f  \n', mean2, sd2)
fprintf('    P_boat       %10.4f        %10.4f  \n', mean3, sd3)
fprintf('    C_boat       %10.4f        %10.4f  \n', mean4, sd4)

clear mean1 mean2 mean3 mean4 sd1 sd2 sd3 sd4

%% Question 1.f:
% Include income as an explanatory variable.
clear all;
clear global; 

% Bring back in the data
global critic_limit iter_limit do_step dh func_name numobs parname ...
       depvar rhsvar nalts mode_id mode
      
[dat,txt,~] = xlsread('new_fish_file.xls');  % read in adjusted dataset
[numr,numc] = size(dat); 

% create dummies for pier, private boat, and charter boat
choice_var = {'CHOICE'};
modeid_var = {'MODE_ID'};
inc_var    = {'INCOME'};
covariates = {'COST','C_RATE'};
mode       = pull_data(txt, choice_var, dat);
mode_id    = pull_data(txt, modeid_var, dat);
income     = pull_data(txt, inc_var,    dat);
covariates = pull_data(txt, covariates, dat);
dum_pier   = mode_id == 2;
dum_pboat  = mode_id == 3;
dum_cboat  = mode_id == 4;

% Create interaction terms with income
pier_inc  = dum_pier.*income;
pboat_inc = dum_pboat.*income;
cboat_inc = dum_cboat.*income;

% Set RHS and depvars
rhsvar = horzcat(covariates, dum_pier, dum_pboat, dum_cboat,...
    pier_inc, pboat_inc, cboat_inc);
depvar = mode;

% Other globals for ML
[nalts,nc] = size(unique(mode_id));
numobs     = numr/nalts;
mode_name  = {'Beach','Pier','Pr Boat','Ch Boat'};
parname    = {'Cost','Catch Rate','Pier','P_Boat','C_Boat','Pier*Inc', 'P_Boat*Inc','C_Boat*Inc'};
critic_limit = 0.00001;
iter_limit   = 250;
do_step      = 1;
func_name    = 'cond_logit_llf';
alpha        = 0.05;
dh           = 0.000001;

% Run the ML estimation
start=inv(rhsvar'*rhsvar)*rhsvar'*mode;
disp('Cond. Logit Estimation - accounting for income heterogeniety');
[b_inc,c_inc,llf_inc] = max_bhhh(start,parname);

%%
diary off;
