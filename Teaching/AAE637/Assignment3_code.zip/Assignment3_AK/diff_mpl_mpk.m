function value=diff_mpl_mpk(parameters)
global rhsvar pred_mult
alpha = parameters(1);
delta = parameters(2);
eta = parameters(3);
rho = parameters(4);

capital = rhsvar(:,1);
labor = rhsvar(:,2);

value=mean((eta.*alpha.^(-rho/eta)).*delta.*(labor.^(-1-rho)).*pred_mult.^(1+(rho./eta)))- ...
      mean((eta.*alpha.^(-rho/eta)).*delta.*(capital.^(-1-rho)).*pred_mult.^(1+(rho./eta)));

end