function [betas_result,cov_result,sse_result] = NLS_master(betas,y,names,type,option)
% Type: 1 for Gauss-Newton; 2 for Newton-Raphson
% Option: 1 to return z-stat; 2 to return t-stat
    switch type
        case 1
            disp('Gauss-Newton Algorithm');
            [betas_result,cov_result,sse_result] = GN(betas, y, names, option);  % Using Gauss Newton Method
        case 2
            disp('Newton-Raphson Algorithm');
            [betas_result,cov_result,sse_result] = NR(betas, y, names, option);  % Using NR Method
        otherwise
            error('Type must be either 1 or 2 (1: GN; 2: NR)')         
    end
end