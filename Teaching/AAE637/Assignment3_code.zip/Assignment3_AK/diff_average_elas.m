function [output]=diff_average_elas(betas)
    global woolp synp;
    beta_2=betas(2);
    beta_3=betas(3);
    lambda= betas(4);
    output= mean(beta_2.*woolp.^lambda)-mean(beta_3.*synp.^lambda);
end
