function [output]=wool_boxcox_relaxed(betas)
    global rhsvar;
    beta_1=betas(1);
    beta_2=betas(2);
    beta_3=betas(3);
    lambda_w= betas(4);
    lambda_s= betas(5);

    output= beta_1 + beta_2 .* (rhsvar(:,1).^lambda_w -1)./lambda_w + ...
        beta_3 .* (rhsvar(:,2).^lambda_s -1)./lambda_s;
end
