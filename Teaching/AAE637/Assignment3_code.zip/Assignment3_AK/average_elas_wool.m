function [output]=average_elas_wool(betas)
    global woolp;
    beta_2=betas(2);
    lambda= betas(4);
    output= mean(beta_2.*woolp.^lambda);
end
