function [output]=average_elas_syn(betas)
    global synp;
    beta_3=betas(3);
    lambda= betas(4);
    output= mean(beta_3.*synp.^lambda);
end
