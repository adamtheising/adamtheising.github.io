%******************************************************
%*****This code is designed to calculate critical******
%*****test statistic values for a number of dist.******
%**It is designed to be called out by another functon**
%***** The return is the critical statistic  **********
%**Alpha_val=level of significance desired(e.g., 0.05)*
%**Stat_Type: 1=Std. Normal, 2=T, 3=Chi-Sq, 4=F *******
%**Test_Type: 1 = 1-tail test, 2 = 2-tail test ********
%********  Two DF are needed for F-Statistic **********
%******************************************************
% Note: we suppress the output display in this version
function [critical] = critical_value_v2(stat_type,test_type,alpha_val,df_1,df_2)
if stat_type == 1;
        if test_type == 1;    %***Standard Normal Distribution*****
            critical = norminv(1-alpha_val);
        else
            alph3=alpha_val/2;
            critical= [norminv(-alph3);norminv(1-alph3)];
        end
  elseif stat_type == 2;      %***T-Distribution *******
   if test_type == 1;
        critical=tinv(1-alpha_val,df_1);
   else
      alph3=alpha_val/2;
      critical=[tinv(-alph3,df_1); tinv(1-alph3,df_1)];
   end
  elseif stat_type == 3;       %****Chi-Square Distribution
   critical=chi2inv(1-alpha_val,df_1);
  elseif stat_type == 4;       %****F Distribution
   critical=finv(1-alpha_val,df_1,df_2);
end

%if test_type == 1;
%    fprintf('This is the one-tail prob. of Type I Error:  %6.4f',alpha_val);disp('  ');
%    fprintf('This is the critical value:  %6.4f', critical);
%else
%    fprintf('This is the two-tail prob. of Type I Error:  %6.4f',alpha_val);disp('  ');
%    fprintf('These are the upper and lower critical values:  %6.4f',critical);
%end
disp('  ')
