function [output]=elas_syn_at_mean(betas)
    global synp;
    beta_3=betas(3);
    lambda= betas(4);
    output= beta_3*mean(synp)^lambda;
end
