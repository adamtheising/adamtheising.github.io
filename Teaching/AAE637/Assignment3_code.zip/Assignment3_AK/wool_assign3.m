function [output]=wool_assign3(betas)
    global rhsvar;
    beta_0=betas(1);
    beta_W=betas(2);
    beta_S=betas(3);
    beta_T=betas(4);
    output = beta_0 .* (rhsvar(:,1).^beta_W) .* (rhsvar(:,2).^beta_S).* ...
        (rhsvar(:,3).^beta_T);
end
