function ret=ces1(betas)
   global rhsvar 
   
   alpha = betas(1);
   delta = betas(2);
   eta = betas(3);
   rho = betas(4);
   
   ret= log(alpha) - (eta./rho).*log(delta.*rhsvar(:,1).^(-rho) ...
       + (1-delta).*rhsvar(:,2).^(-rho));
end

   