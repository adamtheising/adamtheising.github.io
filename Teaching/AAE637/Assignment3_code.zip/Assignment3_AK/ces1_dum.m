function ret=ces1_dum(betas)
   global rhsvar 
   
   alpha = betas(1);
   delta = betas(2);
   eta = betas(3);
   rho = betas(4);
   for i=1:23
   ind_dummy(i,1) = betas(i+4);
   end
   
   ret= log(alpha) - (eta./rho).*log(delta.*rhsvar(:,1).^(-rho) + (1-delta).*rhsvar(:,2).^(-rho))+ ...
        rhsvar(:,3:25)*ind_dummy;
end