function  MPK= ces_mpk_at_mean(betas)
   global K L numobs depvar

   alpha = betas(1);
   delta = betas(2);
   eta = betas(3);
   rho = betas(4);
   
   sse = (log(depvar)-ces1(betas))' * (log(depvar)-ces1(betas));
   
   sigma2 = sse/(numobs-length(betas));
   E_exp_e = exp(sigma2/2);
   pred_output = alpha * (delta * mean(K).^(-rho) + (1-delta) * mean(L).^(-rho)).^(-eta/rho)*E_exp_e;
   
   MPK = delta * eta * pred_output.^(1 + (rho/eta)) .* mean(K).^(-rho - 1);

end
