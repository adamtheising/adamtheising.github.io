function [output]=elas_wool_at_mean(betas)
    global woolp;
    beta_2=betas(2);
    lambda= betas(4);
    output= beta_2*mean(woolp)^lambda;
end
