%{
 ***************************************************************
 **** PROC NLS  ---  NLS - Newton-Raphson algorithm         ****
 ****                using numerical derivatives            ****
 **** Modified from nls.m which uses Gauss-Newton Algorithm ****
 ***************************************************************
%}
function[betas,covb,sse] =  NR(betas,y,names,option)
    global critic_limit iter_limit z numobs do_step func_name stepmin df;
    crit = 1;                   % ** Initialize critical % coef. change **
    v=1;                        % ** Initialize step length **
    iter = 1;                   % ** Initialize iteration count **
    k = length(betas);          % ** Number of parameters **
    while (critic_limit < crit ) &&  (iter < iter_limit); %** Begin loop **
     % ********  Compute numerical gradients **********************
     z = Grad(betas,func_name,numobs);
     H = FHESS('sse_fn',betas); %% Hessian of the SSE function
     % ************************************************************
     u_lag = y - feval(func_name,betas); %** Compute errors | previous betas **
     sl = (H\(2*z'*u_lag));      % Alternative step length
     if do_step == 1;           % ** Use a variable step length **
       v = 2;                   % ** Initialize base step length of 1 **
       ss1 = 1; ss2 = 2;        % ** Initialize SSE's under 2 step lengths
       while (ss1 < ss2) && (v > stepmin);  % ** Loop to determine step length
	     v=v/2;					% ** Update SL for next pass
         u1 = y - feval(func_name,(betas + v*sl/2));% ** Error w/SL/2 & curr. betas
         u2 = y - feval(func_name,(betas + v*sl));  % ** Error w/SL & curr. betas
         ss1 = u1'*u1;           % ** SSE w/SL/2 & curr. betas
         ss2 = u2'*u2;           % ** SSE w/SL & curr. betas
       end 
     end 
 
     b = betas + v*sl;           % ** Update parameters from prevoius **
     u = y - feval(func_name,b);      % ** Create errors given current betas **
     sse = u'*u;                 % ** Calc. SSE's given current betas **
     
     % *** Printing Intermediate Results ****
     diary on;                        % Turn on output to file
     fprintf('i = %3.0f\r', iter);    % Print iteration number
     fprintf('SSE = %8.4f\r', sse);   % Print current SSE
     fprintf('step = %5.4f\r', v); % Print "current" step length
     fprintf('Parameters \r');        % Print current paramater estimate
     format short;
     vv=1;
    	if length(betas)>7;           % Do we have more than 7 parameters?
     		numloop=floor(length(betas)./7); % How many group of 7 parameters?
            resid=length(betas)-numloop*7; % How many parameters
                                           % after the last group of 7
     		while vv<=numloop;
    			disp(b((vv-1)*7+1:vv*7,:)');  % Display 7 parameters 
    			vv=vv+1; 
            end
            if resid>0;     % After the last group of 7 print out remaining
                disp(b((vv-1)*7+1:rows(betas),:)');
                disp(' ')
                disp(' ')
            end
        else
         disp(b');              % Print out all paramatrs if less than 7
        end
     iter = iter + 1;                % ** Update for next iteration**
     crit = max(abs((b - betas)./betas));  % ** Evaluate change in coeff. ** 
     betas = b;                      % ** Create lag betas **
    end
    
    % *** Check if SSE function is convex ***
    H2 = FHESS('sse_fn', betas);
    pos_def = all(eig(H2) > 0);       % or [~, pos_def] = chol(H_check)
    if pos_def == 1
        disp('*** SSE function is convex ***')
    else
        disp('*** SSE function is NOT convex ***')
    end     
    disp(' ');
      
  if iter < iter_limit;
		  %**** Compute covariance matrix *****
		  sighat2 = sse/(numobs - k);    % Unbiased est of error variance
		  covb = inv(z'*z).*sighat2;     % Coefficient cov matrix, JHGLL 12.2.43a             
		  % **** Print out Final Results ******/
		  fprintf('Final Results from NR:  ');
		  disp(' ');
		  stbls=sqrt(diag(covb));        % Column vector of param. std. errors
if option==1
		  zvalue=b./stbls;               % Column vector of z-values
		  df= numobs-k;                  % Degrees of freedom 
		  pvalue=2*(1-normcdf(abs(zvalue),0,1));  % p-values based on standard normal
		  results=horzcat(b,stbls,zvalue,pvalue); % Build results matrix
		  table_bwg(names,results,9);
		  disp('  ')
          end
          if option==2
          tvalue=b./stbls;               % Column vector of t-values
		  df= numobs-k;                  % Degrees of freedom for t-value
		  pvalue=2*(1-tcdf(abs(tvalue),df));  % Column vector of param p-values 
		  results=horzcat(b,stbls,tvalue,pvalue); % Build results matrix
		  table_bwg(names,results,1);
          disp('  ')
          end
          if option~=1 && option~=2
              error('Option must be either 1 or 2 (1: z-stat; 2: t-stat)') 
          end
		  fprintf('Unbiased estimate of error variance:  %10.4f\r', sighat2);
		  ybar = mean(y);
		  sst = y'*y - numobs*(ybar^2);
		  r2 = 1 - (sse/sst);
          fprintf('            Final SSE: %4.4f\r', sse);
		  fprintf('            R-Squared: %4.3f\r', r2);
		  disp('  ')
		  disp('Variance-Covariance Matrix for Estimated Coeff.:')
		  disp(covb);
		 else
		   disp('*******************************************************')
		   disp('Warning:  Iteration limit has been met.  Program has not converged!')
		   disp('*******************************************************')
	end
  diary off;
  %**********************************************************/ 

end

 