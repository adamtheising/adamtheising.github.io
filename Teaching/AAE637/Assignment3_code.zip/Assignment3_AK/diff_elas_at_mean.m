function [output]=diff_elas_at_mean(betas)
    global woolp synp;
    beta_2=betas(2);
    beta_3=betas(3);
    lambda= betas(4);
    output= beta_2*mean(woolp)^lambda-beta_3*mean(synp)^lambda;
end
