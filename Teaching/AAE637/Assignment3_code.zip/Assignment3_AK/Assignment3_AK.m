%% AAE 637, Spring 2018, Assignment #3
% Adam Theising and Charng-Jiun Yu
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% This code and all accompanying functions are based on previous solutions by:
% Chang Lian, Sarah Walker, Travis McArthur, and Eduardo Cenci
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

clear;					    % command to clear memory 
clc;                        % command to clear the command window
clear global;               % clear global variables from memory;
global numobs do_step critic_limit iter_limit dh func_name stepmin depvar rhsvar woolq woolp synp df;

%% Question 1(a) 
% clear previous log file and start it
delete('question1.txt') 
diary('question1.txt');

% Read in data and label columns of interest
[dat,txt] = xlsread('wool_assign_2_18','Wool Data');    % import data
txt = horzcat('Year', txt);
woolq = dat(:,2);
woolp = dat(:,3)/1000; % change the unit for scaling purpose
synp = dat(:,4)/1000;  % change the unit for scaling purpose

[numobs,~] = size(dat);

% Bring in the variables
depvar = log(woolq);
rhsvar = horzcat(woolp, synp);

% Function and parameter names
func_name = 'wool_boxcox';
parname_q1    = {'beta1','beta2','beta3','lambda'};

% Setup for estimation
critic_limit  = 1e-7;  % percentage change in parameters (stopping criterion)
iter_limit    = 250;   % maximum number of iterations
do_step       = 1;     % use variable step length
stepmin       = 0;     % minimum possible step length 
dh            = 1e-7;  % distance for evaluating gradients

% Use initial value from OLS
parname_linear = {'beta2','beta3'};
[betas_ols,~,~,~,~]=basic_ols_proc(rhsvar,depvar,parname_linear,1);   
init_beta = vertcat(betas_ols,1); % initial values


% Call the master NLS function 
% Function input description: NLS_master(staring values,depvar,parname,type,option)
% Type = 1 for GN algorithm
% Type = 2 for NR algorithm
% Option = 1: report z-stat
% Option = 2: report t-stat

% Run the NLS using GN 
[betas_gn,cov_gn,sse_gn] = NLS_master(init_beta,depvar,parname_q1,1,1); 

% Run the NLS using NR 
[betas_nr,cov_nr,sse_nr] = NLS_master(init_beta,depvar,parname_q1,2,1); 

%% Question 1(b)

do_step       = 0;     % use fixed step length
[betas_gn_fixed,cov_gn_fixed] = NLS_master(init_beta,depvar,parname_q1,1,2); 
%[betas_nr_fixed,cov_nr_fixed] = NLS_master(init_beta,depvar,parname_q1,2,2); 

% If we use GN, the estimates and number of iterations will be the same.
% If we use NR, however, the estimates will not converge
%% Question 2(a)
do_step       = 1;     % change back to variable step length for the remaining problem

woolq_hat = exp(wool_boxcox(betas_gn));  % Generate predicted quantity
corr_coef_mat=corrcoef(woolq_hat,woolq); % Calculate correlation coefficient
corr_coef = corr_coef_mat(1,2);    

%% Question 2(b)

mean_woolq_hat = mean(woolq_hat);
mean_woolq = mean(woolq);

% Calculate the standard error of mean_woolq_hat using delta method
grad_woolq_hat = Grad(betas_gn,'wool_boxcox_predicted_average',1);
var_woolq_hat = grad_woolq_hat*cov_gn*grad_woolq_hat';
se_woolq_hat = var_woolq_hat^0.5;

% Conduct t-test
tvalue_woolq_diff=(mean_woolq_hat-mean_woolq)./se_woolq_hat;                      
pvalue_woolq_diff=2*(1-tcdf(abs(tvalue_woolq_diff),numobs-df));   
if pvalue_woolq_diff<0.05
    disp(' ')
    disp('We reject the null hypothesis that the average predicted wool demand is equal to sample average')
else
    disp(' ')
    disp('We do not reject the null hypothesis that the average predicted wool demand is equal to sample average')
end
%% Question 2(c)

% We do this question using F-test. The wool demand does not have the 
% semi-log functional form if beta2 = beta3 = 0. Therefore, the restrcted
% model is a linear regression with only a intercept

% Run the OLS for the restricted model
intercept = ones(numobs,1);
[beta_ols,~,~,~,~,sse_res]=ols_proc_a3(intercept,depvar,{'beta1'},0);  

% F-test
num_res = 2;
num_param_unres = 4;
df1 = num_res;
df2 = numobs-num_param_unres;

fstat= ((sse_res-sse_gn)/df1)/(sse_gn/df2);
crit_value = critical_value_v2(4,2,0.05,df1,df2);  
fprintf(' F-stat: %4.4f\r', fstat);
fprintf(' Critical value: %4.4f\r', crit_value);
if fstat>crit_value
    disp(' ')
    disp('We reject the null hypothesis that wool demand does not have semi-log functional form under 0.05 significance level')
else
    disp(' ')
    disp('We do not reject the null hypothesis that wool demand does not have semi-log functional form under 0.05 significance level')
end

%% Question 2(d)
sum_beta23 = betas_gn(2)+betas_gn(3);
se_sum_beta23 = sqrt(cov_gn(2,2)+cov_gn(3,3)+2*cov_gn(2,3));
tvalue_sum_beta23=sum_beta23/se_sum_beta23;                      
pvalue_sum_beta23=2*(1-tcdf(abs(tvalue_sum_beta23),numobs-df));   
if pvalue_sum_beta23<0.05
    disp(' ')
    disp('We reject the null hypothesis that beta2 = -beta3 under 0.05 significance level')
else
    disp(' ')
    disp('We do not reject the null hypothesis that beta2 = -beta3 under 0.05 significance level')
end

%% Question 2(e), i
own_elas_at_mean = elas_wool_at_mean(betas_gn);
grad_own_elas_at_mean = Grad(betas_gn,'elas_wool_at_mean',1);
var_own_elas_at_mean = grad_own_elas_at_mean*cov_gn*grad_own_elas_at_mean';
se_own_elas_at_mean = var_own_elas_at_mean^0.5;

tvalue_own_elas_at_mean=(own_elas_at_mean+1)/se_own_elas_at_mean;                      
pvalue_own_elas_at_mean=2*(1-tcdf(abs(tvalue_own_elas_at_mean),numobs-df));   
if pvalue_own_elas_at_mean<0.05
    disp(' ')
    disp('We reject the null hypothesis that own-price elasticity = -1 under 0.05 significance level')
else
    disp(' ')
    disp('We do not reject the null hypothesis that own-price elasticity = -1 under 0.05 significance level')
end

%% Question 2(e), ii
cross_elas_at_mean = elas_syn_at_mean(betas_gn);
grad_cross_elas_at_mean = Grad(betas_gn,'elas_syn_at_mean',1);
var_cross_elas_at_mean = grad_cross_elas_at_mean*cov_gn*grad_cross_elas_at_mean';
se_cross_elas_at_mean = var_cross_elas_at_mean^0.5;

tvalue_cross_elas_at_mean=cross_elas_at_mean/se_cross_elas_at_mean;                      
pvalue_cross_elas_at_mean=2*(1-tcdf(abs(tvalue_cross_elas_at_mean),numobs-df));   
if pvalue_cross_elas_at_mean<0.05
    disp(' ')
    disp('We reject the null hypothesis that cross-price elasticity = 0 under 0.05 significance level')
else
    disp(' ')
    disp('We do not reject the null hypothesis that cross-price elasticity = 0 under 0.05 significance level')
end

%% Question 2(e), iii
diff_at_mean = diff_elas_at_mean(betas_gn);
grad_diff_at_mean = Grad(betas_gn,'diff_elas_at_mean',1);
var_diff_at_mean = grad_diff_at_mean*cov_gn*grad_diff_at_mean';
se_diff_at_mean = var_diff_at_mean^0.5;

tvalue_diff_at_mean=diff_at_mean/se_diff_at_mean;                      
pvalue_diff_at_mean=2*(1-tcdf(abs(tvalue_diff_at_mean),numobs-df));   
if pvalue_diff_at_mean<0.05
    disp(' ')
    disp('We reject the null hypothesis that own-price elasticity = -cross-price elasticity under 0.05 significance level')
else
    disp(' ')
    disp('We do not reject the null hypothesis that own-price elasticity = -cross-price elasticity under 0.05 significance level')
end

%% Question 2(f), i
average_own_elas = average_elas_wool(betas_gn);
grad_average_own_elas = Grad(betas_gn,'average_elas_wool',1);
var_average_own_elas = grad_average_own_elas*cov_gn*grad_average_own_elas';
se_average_own_elas = var_average_own_elas^0.5;

tvalue_average_own_elas=(average_own_elas+1)/se_average_own_elas;                      
pvalue_average_own_elas=2*(1-tcdf(abs(tvalue_average_own_elas),numobs-df));   
if pvalue_average_own_elas<0.05
    disp(' ')
    disp('We reject the null hypothesis that own-price elasticity = -1 under 0.05 significance level')
else
    disp(' ')
    disp('We do not reject the null hypothesis that own-price elasticity = -1 under 0.05 significance level')
end

%% Question 2(f), ii
average_cross_elas = average_elas_syn(betas_gn);
grad_average_cross_elas = Grad(betas_gn,'average_elas_syn',1);
var_average_cross_elas = grad_average_cross_elas*cov_gn*grad_average_cross_elas';
se_average_cross_elas = var_average_cross_elas^0.5;

tvalue_average_cross_elas=average_cross_elas/se_average_cross_elas;                      
pvalue_average_cross_elas=2*(1-tcdf(abs(tvalue_average_cross_elas),numobs-df));   
if pvalue_average_cross_elas<0.05
    disp(' ')
    disp('We reject the null hypothesis that cross-price elasticity = 0 under 0.05 significance level')
else
    disp(' ')
    disp('We do not reject the null hypothesis that cross-price elasticity = 0 under 0.05 significance level')
end

%% Question 2(f), iii
diff_average = diff_average_elas(betas_gn);
grad_diff_average = Grad(betas_gn,'diff_average_elas',1);
var_diff_average = grad_diff_average*cov_gn*grad_diff_average';
se_diff_average = var_diff_average^0.5;

tvalue_diff_average=diff_average/se_diff_average;                      
pvalue_diff_average=2*(1-tcdf(abs(tvalue_diff_average),numobs-df));   
if pvalue_diff_average<0.05
    disp(' ')
    disp('We reject the null hypothesis that own-price elasticity = -cross-price elasticity under 0.05 significance level')
else
    disp(' ')
    disp('We do not reject the null hypothesis that own-price elasticity = -cross-price elasticity under 0.05 significance level')
end

%% Question 2(g)

% Setup the relaxed function (lambdas can be different)
func_name = 'wool_boxcox_relaxed';
parname_q2    = {'beta1','beta2','beta3','lambda_w','lambda_s'};
init_beta = vertcat(betas_ols,1,1); % initial values

% Run the NLS using GN 
[betas_gn_relaxed,cov_relaxed,sse_relaxed] = NLS_master(init_beta,depvar,parname_q2,1,1); 

% T-test for the equality of two lambdas
diff_lambdas = betas_gn_relaxed(4)-betas_gn_relaxed(5);
var_diff_lambdas = cov_relaxed(4,4)+cov_relaxed(5,5)-2*cov_relaxed(4,5);
se_diff_lambdas = var_diff_lambdas^0.5;

tvalue_diff_lambdas=diff_lambdas/se_diff_lambdas;       
pvalue_diff_lambdas=2*(1-tcdf(abs(tvalue_diff_lambdas),numobs-df));   
if pvalue_diff_lambdas<0.05
    disp(' ')
    disp('We reject the null hypothesis that two lambdas are equal under 0.05 significance level')
else
    disp(' ')
    disp('We do not reject the null hypothesis that two lambdas are equal under 0.05 significance level')
end

% F-test (SSE based)
num_res = 1;
num_param_unres = 5;
df1 = num_res;
df2 = numobs-num_param_unres;

fstat= ((sse_gn-sse_relaxed)/df1)/(sse_relaxed/df2);
crit_value = critical_value_v2(4,2,0.05,df1,df2);  
fprintf(' F-stat: %4.4f\r', fstat);
fprintf(' Critical value: %4.4f\r', crit_value);
if fstat>crit_value
    disp(' ')
    disp('We reject the null hypothesis that the intercept is the same for all industries under 0.05 significance level')
else
    disp(' ')
    disp('We do not reject the null hypothesis that the intercept is the same for all industries under 0.05 significance level')
end


%%  Question 3

[data,varnames,raw] = xlsread('mizon_1977');

[numobs,numc] = size(data);
quantity = data(:,1);
capital = data(:,2);
labor_raw = data(:,3)/1000;
unemployed = data(:,4)/1000;
hour = data(:,5);
industry = data(:,7);
labor =(labor_raw-unemployed).*hour*52; %labor = (LF - umemp)*hour*52 (annual hours worked)

%%  Question 3(a)
parname_gn = {'alpha','delta','eta','rho'};
critic_limit = 1e-6;
iter_limit = 1e4;
do_step = 1;
dh = 1e-6;
stepmin = 0.1;

% Multiplicative error term [3.1]
func_name = ('ces1');
ln_Q  = log(quantity);
depvar = ln_Q;
rhsvar = horzcat(capital,labor);

%   To get starting values, I sample from the support set and run the GN
%   algorithm three times. Could be smarter and run iteratively for random
%   draws of the support set. We will get the same results from all of
%   these three.

startvalue = [1.1; 0.3; 1.1; 0.5]; 
[betas_mult,cov_mult,sse_mult] = NLS_master(startvalue,depvar,parname_gn,1,2);

%{ 
startvalue = [0.3; 0.9; 5; -0.5];
[betas_mult2,cov_mult2,~] = NLS_master(startvalue,depvar,parname_gn,1,2);

startvalue = [5; 0.2; 5; 5];
[betas_mult3,cov_mult3,~] = NLS_master(startvalue,depvar,parname_gn,1,2);
%}

% Additive error term [3.2]
func_name = ('ces2');
depvar = quantity;
rhsvar = horzcat(capital,labor);

startvalue = [1.1; 0.3; 1.1; 0.5]; 
[betas_add,cov_add,~] = NLS_master(startvalue,depvar,parname_gn,1,2);

%{ 
startvalue = [0.3; 0.5; 2; -0.1];
[betas_add2,cov_add2,~] = NLS_master(startvalue,depvar,parname_gn,1,2);

startvalue = [3; 0.8; 2.5; 1.1];
[betas_add3,cov_add3,~] = NLS_master(startvalue,depvar,parname_gn,1,2);
%}

%%  Question 3(b)
% We know that SSE is at least a local minimum because the SSE is convex at
% the parameter values.

%%  Question 3(c)
%   Be careful when calculating the predicted values of Q_t: need to
%   account for multiplicative error term. I.e. E(exp(eps)) need not be 1.
global pred_mult

sigma2_mult = sse_mult/(numobs-length(betas_mult));
E_exp_e = exp(sigma2_mult/2);

pred_mult = exp(ces1(betas_mult))*E_exp_e;
pred_add = ces2(betas_add);

corr_mat_mult = corrcoef(pred_mult,depvar);
corr_mat_add = corrcoef(pred_add,depvar);
fprintf('Correlation of predicted output for multiplicative form:  %10.4f\r', corr_mat_mult(1,2));
fprintf('Correlation of predicted output for additive form:  %10.4f\r', corr_mat_add(1,2));
disp(' ')

% I.e. the additive framework seems more suitable for the data at hand as
% the correlation coefficient is higher.
% We are interested in this result because it tells us what specification
% is more appropriate for analyzing the data 

%%  Question 3(d) 

%Constant returns to scale means eta is 1

R = [0 0 1 0];
r = 1;
W = (R*betas_mult-r)' * inv(R*cov_mult*R') * (R*betas_mult-r);
df = length(R(:,1));
pval = 1-chi2cdf(W,df);
fprintf('Multiplicative specification: ')
disp('  ')
fprintf('H0: eta=1, Wald statistics is equal to: %10.4f\r' ,W);
if pval<0.05
    disp('Reject H_0 under 0.05 significance level');
else
    disp('Fail to reject H_0 under 0.05 significance level');
end
fprintf('\n');

R = [0 0 1 0];
r = 1;
W = (R*betas_add-r)' * inv(R*cov_add*R') * (R*betas_add-r);
df = length(R(:,1));
pval = 1-chi2cdf(W,df);
fprintf('Additive specification: ')
disp('  ')
fprintf('H0: eta=1, Wald statistics is equal to: %10.4f\r' ,W);
if pval<0.05
    disp('Reject H_0 under 0.05 significance level');
else
    disp('Fail to reject H_0 under 0.05 significance level');
end
fprintf('\n');

%%  Question 3(e) 
global K L 
K = mean(data(:,1));
L = mean(data(:,2));

%   Marginal Product of K
MPK = ces_mpk_at_mean(betas_mult);
fprintf('The MPK = %8.4f\r', MPK);

grad_mpk = Grad(betas_mult,'ces_mpk_at_mean',1);
var_mpk  = grad_mpk*cov_mult*grad_mpk';
fprintf('The Variance of MPK = %8.4f\r', var_mpk);

W_mpk = MPK' * inv(var_mpk) * MPK;
fprintf('The Wald stat of MPK = %8.4f\r', W_mpk);

Wmpk_pval = 1-chi2cdf(W_mpk,1);

if Wmpk_pval<0.05
    disp('Reject H_0 that MPK=0 under 0.05 significance level');
else
    disp('Fail to reject H_0 that MPK=0 under 0.05 significance level');
end
fprintf('\n');

%   Marginal Product of L
MPL = ces_mpl_at_mean(betas_mult);
fprintf('The MPL = %8.4f\r', MPL);

grad_mpl = Grad(betas_mult,'ces_mpl_at_mean',1);
var_mpl = grad_mpl * cov_mult * grad_mpl';
fprintf('The Variance of MPL = %8.4f\r', var_mpl);

W_mpl = MPL' * inv(var_mpl) * MPL;
fprintf('The Wald stat of MPL = %8.4f\r', W_mpl);

Wmpl_pval = 1-chi2cdf(W_mpl,1);

if Wmpl_pval<0.05
    disp('Reject H_0 that MPL=0 under 0.05 significance level');
else
    disp('Fail to reject H_0 that MPL=0 under 0.05 significance level');
end
fprintf('\n');

%%   Question 3(f) 
%   If the MPK and MPL are indeed the same, the MRTS (marginal rate of
%   technical substitution) should be unity.

mrts_LK = ces_mrts(betas_mult);
fprintf('The ratio of MPK/MPL = %8.4f\r', mrts_LK);

var_ratio = Grad(betas_mult,'ces_mrts',1) * cov_mult * Grad(betas_mult,'ces_mrts',1)';
W_ratio = (mrts_LK - 1)' * inv(var_ratio) * (mrts_LK - 1);
fprintf('The Wald stat of ratio of MPK/MPL = %8.4f\r', W_ratio);

Wratio_pval = 1-chi2cdf(W_ratio,1);

fprintf('The p-value of the Wald stat of ratio MPK/MPL = %8.4f\r', Wratio_pval);
if pval<0.05
    disp('Reject H_0 that MPL=MPK under 0.05 significance level');
else
    disp('Fail to reject H_0 that MPL=MPK under 0.05 significance level');
end
fprintf('\n');

%% Question 3(g)

diff = diff_mpl_mpk(betas_mult);
gradient_diff = Grad(betas_mult,'diff_mpl_mpk',1);
variance_diff = gradient_diff*cov_mult*gradient_diff';
standard_error_diff = variance_diff^0.5;
tstat_diff = diff/standard_error_diff;
  if abs(tstat_diff)>1.96
      disp('We reject the null hypothesis that MRL=MRK under 0.05 significance level')
  else
      disp('We do not reject the null hypothesis that MRL=MRK under 0.05 significance level')
  end


%% Question 3(h)

% Generate dummy variables for each industry
for i = 1:24
industry_dummy{i,1} = (industry(:,1)==i);
end

func_name = ('ces1_dum');
ln_Q  = log(quantity);
depvar = ln_Q;

% Here we generate the independent variables containing industry dummies
% Note that we only include 23 dummies to avoid perfect colinearity

% Store the first industry dummy in the vector and than concatenate using a for loop
industry_vec = industry_dummy{1,1}; % {} indicates cell. This allows you to store a matrix in an entry, rather than just a value 
for i =2:23
industry_vec = horzcat(industry_vec,industry_dummy{i,1});
end

rhsvar = horzcat(capital,labor,industry_vec);
startvalue = vertcat([1.1; 0.3; 1.1; 2.1],ones(23,1)); 

parname_gn = {'alpha','delta','eta','rho','ind1','ind2','ind3','ind4'...
              'ind5','ind6','ind7','ind8','ind9','ind10','ind11','ind12', ...
              'ind13','ind14','ind15','ind16','ind17','ind18','ind19','ind20', ...
              'ind21','ind22','ind23'};
          
[betas_ind,cov_ind,sse_ind] = NLS_master(startvalue,depvar,parname_gn,1,1);

% Conduct F-test to see whether all industry dummies are equal to zero
num_res = 23;
num_param_unres = 4;
df1 = num_res;
df2 = numobs-num_param_unres;

fstat= ((sse_mult-sse_ind)/df1)/(sse_ind/df2);
crit_value = critical_value_v2(4,2,0.05,df1,df2);  
fprintf(' F-stat: %4.4f\r', fstat);
fprintf(' Critical value: %4.4f\r', crit_value);
if fstat>crit_value
    disp(' ')
    disp('We reject the null hypothesis that the intercept is the same for all industries under 0.05 significance level')
else
    disp(' ')
    disp('We do not reject the null hypothesis that the intercept is the same for all industries under 0.05 significance level')
end

%% Question 3(i)

do_step = 0; % use fixed step length

% Multiplicative error term [3.1]
func_name = ('ces1');
ln_Q  = log(quantity);
depvar = ln_Q;
rhsvar = horzcat(capital,labor);

startvalue = [1.1; 0.3; 1.1; 0.5]; 
[betas_mult_fixed,cov_mult_fixed,sse_mult_fixed] = NLS_master(startvalue,depvar,parname_gn,1,2);


% Additive error term [3.2]
func_name = ('ces2');
depvar = quantity;
rhsvar = horzcat(capital,labor);

startvalue = [1.1; 0.3; 1.1; 0.5]; 
[betas_add_fixed,cov_add_fixed,~] = NLS_master(startvalue,depvar,parname_gn,1,2);

% If we use GN, the estimates and number of iterations are the same.
% If we use NR, however, estimates won't converge for the additive
% specification