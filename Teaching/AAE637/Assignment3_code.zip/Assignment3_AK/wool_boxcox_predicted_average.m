function [output]=wool_boxcox_predicted_average(betas)
    global rhsvar;
    beta_1=betas(1);
    beta_2=betas(2);
    beta_3=betas(3);
    lambda= betas(4);
    output= mean(exp(beta_1 + beta_2 * (rhsvar(:,1).^lambda -1)./lambda + ...
        beta_3 * (rhsvar(:,2).^lambda -1)./lambda));
end
