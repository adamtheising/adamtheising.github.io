function ret = wool_model_fn(x,y,betas)
     pr_wool = x(:,1);
     pr_synt = x(:,2);
	 err = y - (pr_wool.^betas(1)).*(pr_synt.^betas(2));
     ret = err'*err;
end