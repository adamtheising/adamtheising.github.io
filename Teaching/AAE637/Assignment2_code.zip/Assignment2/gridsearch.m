function [minsse,beta] = gridsearch(func,x,y,beta_ini,increment,index)
   % * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
   % this function based on "gridsearch.m" by Andrew Schreiber
   % * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

   % increments (dynamic)
   [numpar] = size(beta_ini,2);
   guessd = zeros(numpar,index);
    for j = 1: numpar
        for i = 1:round(index/2)
            guessd(j,i) = beta_ini(j) - increment*beta_ini(j)*(round(index/2) - i);
        end
        for i = round(index/2):index
            guessd(j,i) = beta_ini(j) + increment*beta_ini(j)*(i - round(index/2));
        end
    end
    
    % SSE grid values (for 2 parameters)
    sse_grid = zeros(index,index);
    n = 0;      % iteration number;
    for k=1:index
        for j=1:index
            n = n + 1;
            betas = [guessd(1,k) guessd(2,j)];
            sse_grid(k,j) = func(x,y,betas);
            % print first 5 and last 5 iterations
            if n < 6 || n > (index*index-5)
                fprintf('Iteration #:  %i\n', n);
                fprintf('b1:           %8.3f\n', guessd(1,k));
                fprintf('b2:           %8.3f\n', guessd(2,j));
                fprintf('SSE Value:   %8.3f\n', sse_grid(k,j));
                disp(' ');
            end
        end
    end

    % grid search outputs
    [minsse,loc] = min(sse_grid(:));
    [loc_1, loc_2] = ind2sub(size(sse_grid),loc);
    beta(1) = guessd(1,loc_1);
    beta(2) = guessd(2,loc_2);
end