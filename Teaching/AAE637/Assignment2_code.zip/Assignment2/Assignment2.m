%% AAE 637, Spring 2018, Assignment #2
% 2017 AK by Eduardo Cenci; 2018 updates by Adam Theising

% cd Z:\637\Assignment2      % Change as appropriate
clear;					    % command to clear memory 
clc;                        % command to clear the command window
clear global;               % clear global variables from memory;

[dat,txt] = xlsread('wool_assign_2_18','Wool Data');    % import data
txt = horzcat('Year', txt);

% clear previous log file and start it
delete('question1.txt') ;
diary('question1.txt');

% declare global variables
global numobs numcol rhsvar depvar 

% replace missing values (zeroes) for NaN 
nonzero = ~any(dat(:,2:5)==0, 2); % find rows with no 0 value in future log vars 
dat = dat(nonzero,:);             % delete rows with 0 in future log variables
[numobs,numcol] = size(dat);

% create log values (without "zero" issues) and other variables
ln_Quant = log(dat(:,strcmp('Wool_Q',txt)));
ln_PrWool = log(dat(:,strcmp('Wool_P',txt)));
ln_PrSyn = log(dat(:,strcmp('Syn_P',txt)));
ln_Time = log(dat(:,strcmp('Time',txt)));

% create RHS matrix (x) and LHS vector (y)
rhsvar = horzcat(ln_PrWool, ln_PrSyn, ln_Time);
depvar = ln_Quant;

%% Question 1.i - perform estimations 
clear nonzero ln_Quant ln_PrWool ln_PrSyn ln_Time;

% define parameter names (constant is removed if intercept option == 0)
pars = {'constant','ln_PrWool','ln_PrSyn','ln_Time'}; 

% call CRM_AR(1) function using option 0 for no intercept
[b_gls,cov_gls,b_ols,cov_ols,rho,se_rho] = crm_ar1_proc(rhsvar,depvar,pars,1);

% Note the Durbin-Watson statistics is 2.1704, with 
% respective p-value of 0.7925.

%% Question 1.ii - own/cross price effects?
% Are own and cross-price elasts respectively different from -1/1?
tneg1_b2 = (b_gls(2)+1)/sqrt(cov_gls(2,2));
tpos1_b3 = (b_gls(3)-1)/sqrt(cov_gls(3,3));
fprintf('\nT-stat for own-price elasticity = -1 is: %8.4f\n', ...
    tneg1_b2);
fprintf('\nT-stat for cross-price elasticity = 1 is: %8.4f\n', ...
    tpos1_b3);

%% Question 1.iii - are elasticities symmetric?
% elast_own = - elast_cross = 0 <==> beta(1) + beta(2) = 0
theta = b_gls(2) + b_gls(3);
var_theta = cov_gls(2,2) + cov_gls(3,3) + 2*cov_gls(2,3);

tstat = theta/sqrt(var_theta);
pvalue = 2*(1-tcdf(abs(tstat),numobs-2));
fprintf('\nThe t-stat for testing own elasticity = - cross elasticity is %8.4f (p-value = %5.4f)\n',...
        tstat, pvalue);

%% Question 2.i - Single grid search
% clear previous variables and command window 
clear b_gls b_ols cov_gls cov_ols covs pars psi pvalue se_gls se_ols se_rho ...
   rho theta tstat var_theta tneg1_b2 tpos1_b3 depvar rhsvar

% clear previous log file and start it
delete('question2.txt') 
diary('question2.txt');

% redefine RHS matrix (x) and LHS vector (y)
x = dat(:,3:4);
y = dat(:,2);

% Set initial parameters for gridsearch
beta_ini = horzcat(-1, -1); % beta_w, beta_s
index = 500;
increment = 0.05;

[minsse,bgrid] = gridsearch(@wool_model_fn,x,y,beta_ini,increment,index);
fprintf('min SSE:       %8.3f\n', minsse);
fprintf('beta_w:        %8.3f\n', bgrid(1));
fprintf('beta_s:        %8.3f\n', bgrid(2));
disp(' ');

%% Question 3. - adaptive grid search
beta_ini = horzcat(-1, -1); % inital guesses for beta_w, beta_s
index = 500;
increment = 0.05;
[minsse,bgrid] = gridsearch2(@wool_model_fn,x,y,beta_ini,increment,index);

disp(' ');
fprintf('min SSE:       %8.3f\n', minsse);
fprintf('beta_w:        %8.3f\n', bgrid(1));
fprintf('beta_s:        %8.3f\n', bgrid(2));
disp(' ');
