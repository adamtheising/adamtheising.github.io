function [minsse,beta] = gridsearch2(func,x,y,beta_ini,increment,index)
   % * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
   % this function based on "gridsearch.m" by Andrew Schreiber
   % * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
   betaW_diff = 1; % initial difference for 1st param
   betaS_diff = 1; % initial difference for 2nd param
   n = 0;      % adaptive iteration number;
   num_repeat = 0; % repeat count once within threshold
   
   %%
    while num_repeat < 3 % Repeat this number of times while w/in threshold
        % increments (dynamic)
        [numpar] = size(beta_ini,2);
        guessd = zeros(numpar,index);
        for j = 1: numpar
            for i = 1:round(index/2)
                guessd(j,i) = beta_ini(j) - increment*beta_ini(j)*(round(index/2) - i);
            end
            for i = round(index/2):index
                guessd(j,i) = beta_ini(j) + increment*beta_ini(j)*(i - round(index/2));
            end
        end
    
        % SSE grid values (for 2 parameters)
        sse_grid = zeros(index,index);
        for k=1:index
            for j=1:index
                betas = [guessd(1,k) guessd(2,j)];
                sse_grid(k,j) = func(x,y,betas);
            end
        end
        
        % grid search outputs
        n = n + 1;
        [minsse,loc] = min(sse_grid(:));
        [loc_1, loc_2] = ind2sub(size(sse_grid),loc);
        
        fprintf('\nAdaptive iteration:      %8.0f \n', n)
        fprintf('\nStep length:             %8.6f \n', increment)
        fprintf('\nMin SSE:                 %8.3f \n',minsse)
        
        % Difference between old guesses and new
        betaW_diff = guessd(1,loc_1) - beta_ini(1);
        betaS_diff = guessd(2,loc_2) - beta_ini(2) ;
        
        % Update num_repeat if we are within threshold.
        if abs(betaW_diff) <= 0.000001 && abs(betaS_diff) <= 0.000001
                num_repeat = num_repeat + 1;
        end
        
        % Contract the search space by half.
        increment = increment/2;
        
        % Replace previous iteration's guess with new betas.
        beta_ini(1) = guessd(1,loc_1);
        beta_ini(2) = guessd(2,loc_2);
    end
    
        % Final beta parameters after while loop completes.
        beta(1) = guessd(1,loc_1);
        beta(2) = guessd(2,loc_2);
end