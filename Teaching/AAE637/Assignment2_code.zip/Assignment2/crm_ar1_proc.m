function[b_gls,cov_gls,b_ols,cov_ols,rho,se_rho] = crm_ar1_proc(x,y,names,intercept)     

   % * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
   % this function based on "crm_ar1_proc.m" by Andrew Schreiber
   % * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

   % organize data
   [numr,numc]=size(x);                 % Original size of the exogenous data matrix
   if intercept == 1                   % 1 indicates an intercept, 0 no intercept
   	    x = horzcat(ones(numr,1),x);    % Add a vector of 1's
        numc = numc+1;                    % Increase the column count by 1
   else   
            names = names(:,2:end);       % First coefficient is the intercept
   end                                  % Terminate if loop
   
   % CRM estimation
   b_ols = inv(x'*x)*x'*y;              % Estimated Coefficients, CRM Formula 
   df = numr - numc;                    % Degrees of Freedom 
   ehat = y - x*b_ols;                  % Error Vector
   sse = ehat'*ehat;                    % Sum of Squared Errors 
   sighat2 = sse/df;                    % Unbiased Estimate of Error Variance  
   cov_ols = sighat2*inv(x'*x);         % Parameter Covariance Matrix 
   se_ols = sqrt(diag(cov_ols));        % Coefficient Standard Errors    
   tvalue=b_ols./se_ols;                % Coefficient t-values w/ H0:  Beta=0 
   pvalue=2*(1-tcdf(abs(tvalue),df));   % Coefficient p-value (two tail) 
   
   ybar = mean(y);                      % Mean of the dependant variable
   tss = y'*y - numr*(ybar^2);          % Total Sum of Squared Deviations from Mean 
   r2 = 1 - (sse/tss);                  % Coefficient of Determination 
   rbar2 = 1 - (numr-1)*(1-r2)/df;      % Adjusted Coef. of Det.

   % print results
   fprintf('Number of observations:          %i\n',  numr);
   fprintf('Degrees of freedom:              %i\n', df);
   fprintf('Sum of Squared Errors (OLS):     %10.4f\n', sse);
   if intercept == 0
        disp('************************************************');
        disp('   R-sq not restricted to be between 0-1');
        disp('************************************************');
   end
   fprintf('R-squared:             %4.3f\n', r2);
   fprintf('R-bar-squared:         %4.3f\n', rbar2);
   fprintf('Estimate of the error variance:       %10.3f\n', sighat2);
   disp(' ');

   estimates = horzcat(b_ols,se_ols,tvalue,pvalue);
   [numpars,~] = size(estimates);
   fprintf('Table of Results - OLS \n');
   header = {'Variables' 'Value' 'Std.Err' 'T-Value' 'P-Value'};
   fprintf('----------------------------------------------------------------- \n');
   fprintf('%14s %10s %10s %10s %10s  \n', header{1}, header{2}, ...
                                           header{3}, header{4}, header{5});
   fprintf('----------------------------------------------------------------- \n');
   for i = 1:numpars
       fprintf('%14s %10.6f %10.6f %10.6f %10.6f \n', names{i}, estimates(i,:));
   end
   disp('----------------------------------------------------------------- ');    
   disp('  ');
   disp('Estimated Inefficient Coefficient Variance-Covariance Matrix');
   disp(num2str(cov_ols,'%10.4f'))   % Display the parameter covariance matrix
   disp(' ');
   
    
   % test for AR(1) process:   
   e_t = ehat(2:end);
   e_lag = ehat(1:end-1);

   rho = inv(e_lag'*e_lag)*e_lag'*e_t;  % Estimated rho (AR coefficient) 
   vhat = e_t - e_lag*rho;              % Error Vector
   sse_v = vhat'*vhat;                  % Sum of Squared Errors 
   sighat2_rho = sse_v/(numr-1);        % Unbiased Estimate of Error Variance  
   cov_rho = sighat2_rho*inv(e_lag'*e_lag);   % Parameter Covariance Matrix 
   se_rho = sqrt(cov_rho);              % Coefficient Standard Errors    
   test_rho=rho/se_rho;                 % Coefficient t-values w/ H0:  Beta=0 
   pvalue_rho=2*(1-tcdf(abs(test_rho),(numr-1)));   % Coefficient p-value (two tail) 
   
   % weights for efficient variance covariance matrix
   psi_inner = zeros(numr,numr);
    for i = 1:numr
        for j = 1:numr
            psi_inner(i,j) = rho^(abs(j - i));
        end
    end
   psi = (1/(1-rho^2))*psi_inner;
   ipsi = inv(psi);
   
   % FGLS estimation 
   b_gls = inv(x'*ipsi*x)*x'*ipsi*y;    % Estimated Coefficients, GLS Formula 
   egls = y - x*b_gls;                  % Error Vector (GLS)
   sse_gls = egls'*egls;                % Sum of Squared Errors 
   sighat2_v2 = (egls'*ipsi*egls)/df;   % Unbiased Estimate of Error Variance  
   cov_gls = sighat2_v2*inv(x'*ipsi*x); % Efficient Covariance Matrix 
   se_gls = sqrt(diag(cov_gls));        % Coefficient Standard Errors    
   t_gls = b_gls./se_gls;               % Coefficient t-values 
   p_gls = 2*(1-tcdf(abs(t_gls),df));   % Coefficient p-value (two tail) 

   % print results
   fprintf('Estimate of rho:            %10.6f\n' , rho);
   fprintf('Rho t-stat:                 %10.4f\n' , test_rho);   
   fprintf('Rho p-value:                %10.4f\n' , pvalue_rho);
      
   dw_num = (e_t - e_lag).^2;
   dw_den = sse;
   dw = sum(dw_num)/dw_den;
   fprintf('The Durbin-Watson statistic is: %6.4f\n', dw); 
   disp(' ');
   
   estimates = horzcat(b_gls,se_gls,t_gls,p_gls);
   [numpars,~] = size(estimates);
   fprintf('Sum of Squared Errors (FGLS):   %10.4f\n', sse_gls);
   fprintf('Table of Results - FGLS \n');
   header = {'Variables' 'Value' 'Std.Err' 'T-Value' 'P-Value'};
   fprintf('----------------------------------------------------------------- \n');
   fprintf('%14s %10s %10s %10s %10s  \n', header{1}, header{2}, ...
                                           header{3}, header{4}, header{5});
   fprintf('----------------------------------------------------------------- \n');
   for i = 1:numpars
       fprintf('%14s %10.6f %10.6f %10.6f %10.6f \n', names{i}, estimates(i,:));
   end
   disp('----------------------------------------------------------------- ');    
   disp('  ');
   disp('Estimated Efficient Coefficient Variance-Covariance Matrix with AR(1)');
   disp(num2str(cov_gls,'%10.4f'))
   disp(' ');

end