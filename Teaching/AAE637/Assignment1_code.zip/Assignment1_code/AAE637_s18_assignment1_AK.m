%% AAE 637, Spring 2018, Assignment #1
% Answer key by Eduardo Cenci, w/ edits by Adam Theising and Charng-Jiun Yu
clear;					    % command to clear memory 
clc;                        % command to clear the command window
[dat,txt,raw] = xlsread('RECS_Data_2009_base.xlsx','Data'); % import data  

%% Question 1.b
% Clear previous log file and start it
delete('question1.txt') 
diary ('question1.txt');
m_PercapKWH = nanmean(dat(:,15)); % nanmean finds mean while ignoring all missing rows
std_PercapKWH = nanstd(dat(:,15)); % same as above but for std
nonmissobs = sum(~isnan(dat(:,15))); % count number of non-missing obs for PercapKWH
tstat = sqrt(nonmissobs)*((m_PercapKWH-3750)/std_PercapKWH); % calculate standard student t-stat
pvalue = 2*(1-tcdf(abs(tstat),nonmissobs-1)); % p-value, drawing from cdf of student t dist
fprintf('\nThe t-stat for a test that the mean of PC KWH = 3750 is%8.4f and its p-value is %5.4f\n',...
         tstat, pvalue);

clear m_PercapKWH std_PercapKWH tstat nonmissobs pvalue;

%% Question 1.c
% First, find mean and sd of P/C KWH for subsample w/ < 2750 sq ft H/C
HC_lt = find(dat(:,6)<2750); % return a vector of indices for obs with H/C<2750     
    lt = dat(HC_lt,:); % create a matrix using only rows from the index vector (lt) above. 
    [n1,~] = size(lt); % count number of observations in H/C<7500 subsample
    m1 = mean(lt(:,15)); % mean of lt subsample
    var1 = var(lt(:,15)); % sd of ht subsample
%%
% Now, mean and sd of P/C KWH for subsample w/ >= 2750 sq ft H/C
HC_gt = find(dat(:,6)>=2750); % return a vector of indices for obs with H/C<2750
    gt = dat(HC_gt,:); % create a matrix using only rows from the index vector (gt) above.
    [n2,~] = size(gt); % count number of observations in H/C>=2750 subsample
    m2 = mean(gt(:,15)); % mean of ht subsample
    var2 = var(gt(:,15)); % sd of ht subsample
%%
% Calculate the difference in means, and t-test against zero
diff = m2 - m1; % testing whether the difference in means is different from 0
std_diff = sqrt( var2/n2 + var1/n1); % sd formula for additive fct of two subsamples
tstat = diff/std_diff; 
pvalue = 2*(1-tcdf(abs(tstat),(n1+n2)-1));
fprintf('\nThe t-stat for testing the equality of the subgroup means is %8.4f (p-value = %5.4f)\n',...
         tstat, pvalue);
     
clear m1 m2 gt lt t HC_lt HC_gt n1 n2 var1 var2 diff std_diff tstat pvalue;
diary off;

%% Question 2.a. 
% Clean data for analysis
nonzero = ~any(dat(:,[1 2 3 6 7])==0, 2); % find rows with no 0 value in future log vars 
dat = dat(nonzero,:);  % delete rows with 0 in future log variables
dat(any(isnan(dat),2),:) = [] ; % drop rows with NaNs
[numobs,~] = size(dat); % number of obs in restricted dataset
%%
% For each of these variables, call the only the column of interest
ln_HDD65 = log(dat(:,1));
ln_CDD65 = log(dat(:,2));
ln_House_Age = log(dat(:,3));
HHSize = dat(:,4);
ln_Tot_SqFt_HC = log(dat(:,6));
ln_HH_Inc = log(dat(:,7));
Elec_Pr = dat(:,8);
KWH = dat(:,14);
%%
% Create dependent variable (y) and independent variables (x)
intercept = ones(numobs,1); % don't forget an intercept!
x = horzcat(intercept, ln_HDD65, ln_CDD65, ln_House_Age, HHSize, ...
    ln_Tot_SqFt_HC, ln_HH_Inc, Elec_Pr);
coef_names = {'intercept' 'ln_HDD65' 'ln_CDD65' 'ln_House_Age' 'HHSize' ...
    'ln_Tot_SqFt_HC' 'ln_HH_Inc' 'Elec_Pr'}; % names of RHS variables for results table
y = KWH;
[~,covs] = size(x);
clear nonzero intercept ln_HDD65 ln_CDD65 ln_House_Age HHSize  ...
    ln_Tot_SqFt_HC ln_HH_Inc Elec_Pr KWH ;
%%
% Estimate coefficients and statistics of interest: (h/t to Travis McArthur) 
beta = inv(x'*x)*x'*y;               % OLS (CRM) coefficients
df = numobs - covs;                  % degrees of freedom 
ehat = y - x*beta;                   % errors
sse = ehat'*ehat;                    % Sum of Squared Errors 
sighat2 = sse/df;                    % unbiased estimate of error variance  
covb = sighat2*inv(x'*x);            % covariance matrix under homoscedasticity 
ybar = mean(y);                      % mean of the dependent variable
tss = y'*y - numobs*(ybar^2);        % Sum of Squared Deviations from the mean 
r2 = 1 - (sse/tss);                  % coefficient of determination 
rbar2 = 1 - (numobs-1)*(1-r2)/df;    % adjusted coefficient of determination
stde = sqrt(diag(covb));             % standard errors of coefficients
tvalue = beta./stde;                 % t-values of coefficient for H0: beta = 0 
pvalue = 2*(1-tcdf(abs(tvalue),df)); % p-value of coefficients(two tail) 
ecls = y - ybar;                     % constrained errors for F statistic
sse_cls = ecls'*ecls;
fstat = (sse_cls - sse)/(sighat2*(covs-1));   % F statistic
%%
% Now, piece together and output the results table.
% First, overall regression stats and preliminary information.
% Then, table of parameter estimates and stats.
disp('  ');
fprintf('Nr. of observations used = %8.0f \n', numobs);
fprintf('F-statistic = %4.4f \n', fstat);
fprintf('R^2 =  %4.4f \n', r2);
fprintf('adjusted R^2 =  %4.4f \n', rbar2);
fprintf('Estimate of the error variance = %10.4f \n', sighat2');
fprintf('  \n');
% Coef estimates, std errors, t- and p-values:
coef_ests = horzcat(beta, stde, tvalue, pvalue); % concat results of interest
table_bwg(coef_names, coef_ests, 1); % output using table_bwg.m
% variance and covariance matrix
fprintf('Parameter covariance matrix = \n');
disp(covb);
%% Question 2.b. 
% Calculate the means of the RAW data 
means = mean(dat);  
hdd_bar = means(1);      % mean of HDD     
cdd_bar = means(2);      % mean of CDD
%%
% Next, the individual marginal effects for each var
marg_HDD = beta(2)/hdd_bar; % marginal of beta*ln(x) is beta/x - here xbar
fprintf('\nThe marginal effect of HDD at the mean of the data is %8.4f', ...
        marg_HDD);
marg_CDD = beta(3)/cdd_bar; % marginal of beta*ln(x) is beta/x - here xbar
fprintf('\nThe marginal effect of CDD at the mean of the data is %8.4f', ...
        marg_CDD);
%%
% Finally, compare the marginal effects
diff = marg_HDD - marg_CDD; % difference in effects
var_diff = (hdd_bar^-2)*covb(2,2) + (cdd_bar^-2)*covb(3,3) - ...
           (hdd_bar^-1)*(cdd_bar^-1)*2*covb(2,3); % don't forget covar term here
tstat = diff/sqrt(var_diff);
pvalue = 2*(1-tcdf(abs(tstat),numobs-2));
fprintf('\nThe t-stat for testing the equality of marginal effects is %8.4f (p-value = %5.4f)\n',...
        tstat, pvalue);

clear marg_CDD marg_HDD hdd_bar cdd_bar;

%% Question 2.c. 
% Calculate mean of KWH, then find elasticities
kwh_bar = means(14);      % mean of KWH     
elast_HDD = beta(2)/kwh_bar; % marginal effect * (hdd_bar/kwh_bar)
fprintf('\nThe elasticity of HDD at the mean of the data is %8.4f', ...
        elast_HDD);
elast_CDD = beta(3)/kwh_bar; % marginal effect * (cdd_bar/kwh_bar)
fprintf('\nThe elasticity of CDD at the mean of the data is %8.4f', ...
        elast_CDD);
%%
% Test elasticity differences
% Note that: elast_HDD - elast_CDD = 0 <==> beta(2) - beta(3) = 0
diff = beta(2) - beta(3);
var_diff = covb(2,2) + covb(3,3) - 2*covb(2,3);
tstat = diff/sqrt(var_diff);
pvalue = 2*(1-tcdf(abs(tstat),numobs-2));
fprintf('\nThe t-stat for testing the equality of elasticities is %8.4f (p-value = %5.4f)\n',...
        tstat, pvalue);
    
clear kwh_bar elast_HDD elast_CDD;

%% Question 2.d. 
% Calculate price elasticity
pk_bar = means(8)/means(14);   % mean of price over mean of KWH
elast_P = beta(8)*pk_bar; % marg effect of price * (price/KWH)
var_elastp = (pk_bar^2)*covb(8,8); % calc var of elasticity for tests below
fprintf('\nThe price elasticity at the mean of the data is %8.4f', ...
        elast_P);
%%   
% Test price elasticity = 0
tstat = (elast_P-0)/sqrt(var_elastp);
pvalue = 2*(1-tcdf(abs(tstat),numobs-1));
fprintf('\nThe t-stat for testing price elasticity equal to zero is %8.4f (p-value = %5.4f)',...
        tstat, pvalue);
%%
% Test price elasticity < -1
tstat = (elast_P-(-1))/sqrt(var_elastp);
pvalue = 2*(1-tcdf(tstat,numobs-1));
fprintf('\nThe t-stat for testing price elasticity less than -1 is %8.4f (p-value = %5.4f)\n',...
        tstat, pvalue);

clear means elast_P pk_bar var_elastp tstat pvalue;

%% Question 2.e  
% We will use an F-test to compare b/w models w/ and w/o these two variables
z = horzcat(x(:,1),x(:,4:8));   % matrix w/ restricted vector of covariates
[~,covs_r] = size(z);           % number of restricted covariates
q = covs - covs_r;              % # of additional covariates in complete model
bred = inv(z'*z)*z'*y;          % (restricted) OLS coefficients 
ered = y - z*bred;              % (restricted) errors 
sse_r = ered'*ered;             % (restricted) Sum of Squared Errors
df_r = numobs - covs_r;         % (restricted) degrees of freedom 
r2_r = 1 - (sse_r/tss);         % r2
rbar2_r = 1 - (numobs-1)*(1-r2_r)/df_r;    % adjusted r2 
fstat = ((sse_r - sse)/q)/(sse/df);   % F statistic

fprintf('\nThe F-stat to test if the restricted model is "true" is %8.4f\n', ...
        fstat);

clear beta bred coef_ests covb covs covs_r df df_r diff ...
    ecls ehat ered fstat q r2 r2_r rbar2 rbar2_r sighat2 sse sse_cls ...
    sse_r stde tss tvalue var_diff ybar z
%% Question 3
% Call basic_ols_proc.m, using the appropriate function inputs. Note
% that results in table should be identical to those from Q2 table.


% Drop intercept column from x matrix and coef_names matrix
x = x(:,2:8);
coef_names_toreg = coef_names(:,2:8);

% Gen coefficient estimates and output to table.
[beta,se,tval,pval,covb,fstat,r2,rbar2,sighat2] = basic_ols_proc(x,y,coef_names_toreg,1);
disp('  ');
fprintf('Nr. of observations used = %8.0f \n', numobs);
fprintf('F-statistic = %4.4f \n', fstat);
fprintf('R^2 =  %4.4f \n', r2);
fprintf('adjusted R^2 =  %4.4f \n', rbar2);
fprintf('Estimate of the error variance = %10.4f \n', sighat2');
coef_ests = horzcat(beta, se, tval, pval); % concat results of interest
table_bwg(coef_names, coef_ests, 1); % output using table_bwg.m
fprintf('  \n');
fprintf('Parameter covariance matrix = \n');
disp(covb);
clear beta se tval pval coef_ests

%% Question 4.a
% Create interaction HH_Inc x Price
var1 = dat(:,7);
var2 = dat(:,8);
inc_price = (var1.*var2)/1000;     % scaled up
%%
% Add interaction term to list of RHS variables
x = horzcat(x,inc_price); % add new variable to regression matrix
coef_names = horzcat(coef_names, 'Income x Price'); % update names
coef_names_toreg = coef_names(:,2:9); % no intercept name when using basic_ols_proc

[beta,se,tval,pval,vcov_mat,fstat,r2,rbar2,sighat2] = basic_ols_proc(x,y,coef_names_toreg,1);
disp('  ');
fprintf('Nr. of observations used = %8.0f \n', numobs);
fprintf('F-statistic = %4.4f \n', fstat);
fprintf('R^2 =  %4.4f \n', r2);
fprintf('adjusted R^2 =  %4.4f \n', rbar2);
fprintf('Estimate of the error variance = %10.4f \n', sighat2');
coef_ests = horzcat(beta, se, tval, pval); % concat results of interest
table_bwg(coef_names, coef_ests, 1); % output using table_bwg.m
fprintf('  \n');
fprintf('Parameter covariance matrix = \n');
disp(vcov_mat)

%% Question 4.b 
% Calculate the means of the RAW data 
means = mean(dat);  % calculate the means of the data 
pk_bar = means(8)/means(14);   % mean of price over mean of KWH
inc_bar = means(7);         % mean of income
%%
% Calculate elasticity and test difference from -1
elast_P = (beta(8)+beta(9)*inc_bar/1000)*pk_bar; % marginal effect * (price/KWH)
var_diff = (pk_bar^2)*(vcov_mat(8,8) + ((inc_bar/1000)^2)*vcov_mat(9,9) + 2*(inc_bar/1000)*vcov_mat(8,9));
fprintf('\nThe price elasticity at the mean of the data is %8.4f', ...
        elast_P);
tstat = (elast_P - (-1))/sqrt(var_diff);
pvalue = 2*(1-tcdf(abs(tstat),numobs-2));
fprintf('\nThe t-stat for testing price elasticity equal to -1 is %8.4f (p-value = %5.4f)\n',...
        tstat, pvalue);

clear elast_P var_diff tstat pvalue 
    
%% Question 4.c
% Calculate the means of the RAW data 
invkwh_bar = (1/means(14));                % inverse of mean of KWH
pri_inc_bar = (means(8)*means(7));    % mean of price times mean of income
%%
% Find elasticity and test against 0.5
elast_I = (beta(7)+beta(9)*pri_inc_bar/1000)*invkwh_bar;
var_diff = invkwh_bar^2*(vcov_mat(7,7) + (pri_inc_bar/1000)^2*vcov_mat(9,9) + 2*(pri_inc_bar/1000)*vcov_mat(7,9));
fprintf('\nThe income elasticity at the mean of the data is %8.4f', ...
        elast_I);
tstat = (elast_I - 0.5)/sqrt(var_diff);
pvalue = 2*(1-tcdf(abs(tstat),numobs-3));
fprintf('\nThe t-stat for testing income elasticity equal to 0.5 is %8.4f (p-value = %5.4f)\n',...
        tstat, pvalue);
   
clear var_diff elast_I tstat pvalue

%% Question 4.d
% Calculate elasticities then test their joint difference against zero.
elast75 = (beta(7)+beta(9)*(0.75*pri_inc_bar)/1000)*invkwh_bar; % price @ 75% mean
elast150 = (beta(7)+beta(9)*(1.5*pri_inc_bar)/1000)*invkwh_bar; % price @ 150% mean
var_diff = (0.75*pri_inc_bar*invkwh_bar/1000)^2*vcov_mat(9,9); % analytically calc elast150-elast75...
tstat = (elast150-elast75)/sqrt(var_diff);
pvalue = 2*(1-tcdf(abs(tstat),numobs-3));
fprintf('\nThe t-stat for a test of whether income elasticity varies at');
fprintf(' 75 versus 150 percent of mean income is%8.4f (p-value = %5.4f)\n',...
        tstat, pvalue);
