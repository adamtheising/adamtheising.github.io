function[bls,stbls,tvalue,pvalue,covb,fstat,r2,rbar2,sighat2]=basic_ols_proc(x,y,names,intercept)     
   [numr,numc]=size(x);                 % Original size of the exogenous data matrix
   if intercept == 1;                        % 1 indicates an intercept, 0 no intercept
   	    x = horzcat(ones(numr,1),x); % Add a vector of 1's
        names = horzcat('Intercept', names);
        numc=numc+1;                      % Increase the column count by 1
   end                                              % Terminate if loop
   bls = inv(x'*x)*x'*y;                   % Estimated Coefficients, CRM Formula 
   df = numr - numc;                       % Degrees of Freedom 
   ehat = y - x*bls;                          % Error Vector
   sse = ehat'*ehat;                          % Sum of Squared Errors 
   sighat2 = sse/df;                         %Unbiased Estimate of Error Variance  
   covb = sighat2*inv(x'*x);           % Parameter Covariance Matrix 
   ybar = mean(y);                          % Mean of the dependant variable
   tss = y'*y - numr*(ybar^2);         % Total Sum of Squared Deviations from Mean 
   r2 = 1 - (sse/tss);                        % Coefficient of Determination 
   rbar2 = 1 - (numr-1)*(1-r2)/df;  % Adjusted Coef. of Det.
   stbls = sqrt(diag(covb));	        % Coefficient Standard Errors 
   tvalue=bls./stbls;                        % Coefficient t-values w/ H0:  Beta=0 
   pvalue=2*(1-tcdf(abs(tvalue),df));   % Coefficient p-value (two tail)
   
   ecls = y - ybar;                     % constrained errors for F statistic
   sse_cls = ecls'*ecls;
   fstat = (sse_cls - sse)/(sighat2*(numc-1));   % F statistic
end
   

